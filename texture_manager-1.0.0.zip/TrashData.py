from bpy.types import Material,NodeTree,Image
from typing import Set
import bpy

class TrashData:
    nodeGroups:Set[NodeTree]=set()
    materials:Set[Material]=set()
    images:Set[Image]=set()
    @staticmethod
    def Delete():
        for nodeGroup in reversed(list(TrashData.nodeGroups)):
            bpy.data.node_groups.remove(nodeGroup)
        for material in reversed(list(TrashData.materials)):
            bpy.data.materials.remove(material)
        for image in reversed(list(TrashData.images)):
            bpy.data.images.remove(image)
        TrashData.nodeGroups=set()
        TrashData.materials=set()
        TrashData.images=set()
