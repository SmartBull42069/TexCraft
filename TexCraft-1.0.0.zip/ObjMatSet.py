from bpy.types import Material,Object,NodeTree
from .TrashData import TrashData
import bpy

class ObjectData:
    def __init__(self, mesh:Object):
        self.object:Object = mesh
        self.matData:dict[int,Material]={}
        self.matName:dict[Material,str]={}
        self.skipMat:set[Material]=set()
        self.CreateObjData()

    def CreateObjData(self):
        for i in range(len(self.object.data.materials)):
            currentMat:Material=self.object.data.materials[i]
            if(bpy.context.scene.CopyMaterial and bpy.context.scene.ApplyMaterial):
                copiedMat:Material=self.CopySetMaterial(i)
                if((bpy.context.scene.BakeMulitpleSlots and i==0 and bpy.context.scene.CollapseSlot) or ((not bpy.context.scene.BakeMulitpleSlots) or not (bpy.context.scene.CollapseSlot))):
                    self.matData[i]=copiedMat
                else:
                    TrashData.materials.add(copiedMat)
            else:
                if((bpy.context.scene.BakeMulitpleSlots and i==0 and bpy.context.scene.ApplyMaterial and bpy.context.scene.CollapseSlot) or (not (bpy.context.scene.BakeMulitpleSlots) or not (bpy.context.scene.ApplyMaterial) or not (bpy.context.scene.CollapseSlot))):
                    self.matData[i]=currentMat
                else:
                    self.skipMat.add(currentMat)
            if(bpy.context.scene.CopyNodeGroup):
                nodeGroupsDel:set[NodeTree]=self.CopyNodeGroup()
                if(not bpy.context.scene.ApplyMaterial):
                    TrashData.nodeGroups.update(nodeGroupsDel)
            
    def SetMat(self):
        for i in self.matData:
            self.object.data.materials[i]=self.matData[i]
        for i in range(len(self.object.data.materials)-1,-1,-1):
            if(i not in self.matData):
                self.object.data.materials.pop(index=i)
    def RemoveFromData(self,data:dict):
        matToDelet:set[Material]=set()
        for mat in data:
            if((mat in TrashData.materials) or (mat in self.skipMat)):
                matToDelet.add(mat)
        for mat in matToDelet:
            del data[mat]
    def CopyNodeGroup(self):
        nodeGroup = set()
        nodeTree=set()
        for node in self.object.data.node_tree.nodes:
            if (type(node) == bpy.types.ShaderNodeGroup):
                group = node.node_tree
                if(group):
                    copied = group.copy()
                    node.node_tree = copied
                    nodeGroup.add(node)
                    nodeTree.add(node.node_tree)
        for groups in nodeGroup:
            deepCopy=self.CopyNodeGroup(groups)
            nodeTree.update(deepCopy)
        return set(nodeTree)
    def CopySetMaterial(self, index: int) -> Material:
        ogMat:Material=self.object.material_slots[index].material
        mat: Material = self.object.material_slots[index].material.copy()
        self.object.material_slots[index].material = mat
        mat.name = self.GetMaterialName(ogMat)
        return mat
    def GetMaterialName(self, mat:Material):
        name = bpy.context.scene.MaterialName
        if (name != ""):
            name = name.replace("[obj]", self.object.name)
            name = name.replace("[mat]", mat.name)
            return name
        else:
            return mat.name

        