import bpy
from bpy.types import Material,Node,NodeSocket,NodeSocketShader,bpy_prop_array
from typing import Union

class Connection:

    def CreateLink(mats: Material, InputValueNode: Node, OutPutValueNode:Union[ NodeSocket,float,int], mapTypeOrSocket: str):
        if(type(mapTypeOrSocket)==str or type(mapTypeOrSocket)==int):
            inputSocket=InputValueNode.inputs[mapTypeOrSocket]
        else:
            inputSocket=mapTypeOrSocket
        if ((type(OutPutValueNode) == float) or (type(OutPutValueNode) == int)):
            if (inputSocket.is_linked):
                mats.node_tree.links.remove(
                    inputSocket.links[0])
            if (type(inputSocket.default_value) == float or type(inputSocket.default_value) == int):
                inputSocket.default_value = OutPutValueNode
            else:
                inputSocket.default_value[:] = (
                    OutPutValueNode,)*len(inputSocket.default_value[:])
        elif (type(OutPutValueNode) == tuple):
            if (inputSocket.is_linked):
                mats.node_tree.links.remove(
                    inputSocket.links[0])
            if (type(inputSocket.default_value) == float or type(inputSocket.default_value) == int):
                inputSocket.default_value = OutPutValueNode[0]
            else:
                for i,value in enumerate(OutPutValueNode):
                    inputSocket.default_value[i]=value
        else:
            input: NodeSocket = inputSocket
            mats.node_tree.links.new(input, OutPutValueNode)
    
def BreakLink(ConnectionNode: Node, mats: Material, mapType: str):

    if(type(mapType)!=str):
        inputName=mapType
    else:
        if(mapType not in bpy.context.scene.inputNodeNames):
            inputName=mapType
        else:
            inputName=bpy.context.scene.inputNodeNames[mapType]
    dependant=bpy.context.scene.propertyDependentInput
    input: NodeSocket = ConnectionNode.inputs[inputName]
    hasLinks: bool = False

    if (input.is_linked):
        hasLinks = True
        FromSocket: Node = input.links[0].from_socket
        mats.node_tree.links.remove(input.links[0])
    if (type(input) == NodeSocketShader):
        if (hasLinks):
            return FromSocket
        else:
            return None
    tempNode:Node = mats.node_tree.nodes.new(type=ConnectionNode.bl_idname)
    if mapType in dependant:
        propertyToSet=dependant[mapType]["Property"]
        value=dependant[mapType]["PropertyAccept"][0]
        setattr(tempNode,propertyToSet,value)
    defaultValue = tempNode.inputs[inputName]

    if (type(input.default_value) == bpy_prop_array):
        breakedInputValue = input.default_value[:]
    else:
        breakedInputValue = input.default_value
    if (type(input.default_value) == float or type(input.default_value) == int):
        input.default_value = defaultValue.default_value
    elif (type(input.default_value) == bpy_prop_array):
        input.default_value = defaultValue.default_value[:]
    mats.node_tree.nodes.remove(tempNode)
    if (hasLinks):
        return FromSocket
    else:
        return breakedInputValue