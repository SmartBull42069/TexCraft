import bpy
from bpy.types import Material,Object
class Name:
    @staticmethod
    def GetMeshNameToUse(mesh:Object, isEnable:bool):
        if(bpy.context.scene.BakeMultiple and isEnable):
            return"combine"
        return mesh.name
    @staticmethod
    def GetMatNameToUse(mat:Material,isEnable:bool):
        if(bpy.context.scene.BakeMultiple and isEnable):
            return "combine"
        return mat
    @staticmethod
    def GetImageName(mats:Material, mesh:Object, imageObj):
        fileName: str = imageObj.naming
        fileName = fileName.replace("[mat]", mats)
        fileName = fileName.replace("[obj]", mesh)
        origianlName = fileName
        fileName = fileName.replace("[Num]", "")
        
        num = 1

        while (bpy.data.images.get(fileName, None) != None):
            if ("[Num]" in origianlName):
                fileName = origianlName.replace("[Num]", f"{num}")
            else:
                fileName = f"{origianlName}{num}"
            num += 1
        return fileName