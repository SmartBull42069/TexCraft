from enum import Enum

class InputStatus(Enum):
    PROCEDUAL = 1
    TEXTURE = 2
    DEFAULT = 3

class Channel(Enum):
    FULL = "Full"
    RED = "Red"
    GREEN = "Green"
    BLUE = "Blue"
    ALPHA = "Alpha"
