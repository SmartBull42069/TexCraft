import bpy
from bpy.types import MeshUVLoopLayer,Object


class UvManager:
    @staticmethod
    def SetUv(uvMap: MeshUVLoopLayer, mesh: Object):
        try:
            mesh.data.uv_layers[uvMap].active = True
        except:
            pass