import bpy
from bpy_extras.io_utils import ImportHelper
import os
import json
from pathlib import Path
from .Category import Catergory

def ApplyCurrentSetting(self, context):
    if (context.scene.SavedSettings=="None"):
        return
    try:
        with open(context.scene.SavedSettings, "r+") as file:
            print(context.scene.SavedSettings)
            tempObj = json.load(file)
            for property in tempObj:
                setattr(context.scene, property, tempObj[property])
            setattr(context.scene, "MaterialName", tempObj["MaterialName"])
            setattr(context.scene, "settingName",tempObj["settingName"])

            setattr(context.scene, "compression", tempObj["compression"])
            setattr(context.scene, "quality", tempObj["quality"])
            setattr(context.scene, "exrCodec", tempObj["exrCodec"])
            setattr(context.scene, "tiffCodec", tempObj["tiffCodec"])

            setattr(context.scene, "UVIslandMargin", tempObj["UVIslandMargin"])
            setattr(context.scene, "angleLimit", tempObj["angleLimit"])
            setattr(context.scene, "areaWeight", tempObj["areaWeight"])
            setattr(context.scene, "scaleToBound", tempObj["scaleToBound"])
            setattr(context.scene, "CorrectAspectRatio", tempObj["CorrectAspectRatio"])
            setattr(context.scene, "MarginMethod", tempObj["MarginMethod"])
            setattr(context.scene, "RotateMethod", tempObj["RotateMethod"])
            setattr(context.scene, "settingName", Path(context.scene.SavedSettings).stem)
            setattr(context.scene, "CopyMaterial", tempObj["CopyMaterial"])
            setattr(context.scene, "CollapseSlot", tempObj["CollapseSlot"])
            
            
    except Exception as e:
        print(f"setting {e} error")


def getSavedSetting(self, context):
    createdEnums = [("None","None","None")]
    folder = context.scene.SavedSettingFolder
    os.makedirs(folder, exist_ok=True)
    files = [f for f in os.listdir(folder)]
    for file in files:
        createdEnums.append(
            (f"{folder}/{file}", Path(file).stem, f"Current setting is {file}"))
    return createdEnums


def SetCopiedMaterialDefault(self, context):
    if (not context.scene.CopyMaterial):
        context.scene.MaterialName = ""




class SETTING_PT_PANEL(bpy.types.Panel):
    bl_label = "Settings"
    bl_idname = "SCENE_PT_Setting_Manager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = Catergory.GetCategory()

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        column = layout.column()
        numOfItem = list(scene.settingsNames.keys())
        for i in range(0, len(numOfItem), 3):
            settingNames = numOfItem[i:i+3]
            row = column.row()
            for names in settingNames:
                row.prop(
                    scene, names, toggle=True, text=scene.settingsNames[names])
        
        if(scene.ApplyMaterial):
            newRow = column.row()
            newRow.prop(
                    scene, "CopyMaterial", toggle=True, text="Copy Material")
            if(scene.BakeMulitpleSlots):
                newRow.prop(
                    scene, "CollapseSlot", toggle=True, text="Collapse Slot")
        if (scene.CopyMaterial  and scene.ApplyMaterial):
            materialNameRow = column.row()
            materialNameRow.prop(
                scene, "MaterialName",text="Material Name")
            
        column.separator()
        currentSettingRow = column.row()
        currentSettingRow.prop(scene, "settingName", text="setting name")
        currentSettingRow.prop(scene, "SavedSettings", text="Current setting")
        if(scene.FileFormat=="png"):
            compressionRow=column.row()
            compressionRow.prop(
                scene, "compression",text="Compression")
        
        if(scene.FileFormat=="jpg"):
            compressionRow=column.row()
            compressionRow.prop(
                scene, "quality",text="quality")
        if(scene.FileFormat=="exr"):
            exrCodec=column.row()
            exrCodec.prop(
                scene, "exrCodec",text="Codec")
        if(scene.FileFormat=="tiff"):
            tiffCodec=column.row()
            tiffCodec.prop(
                scene, "tiffCodec",text="Codec")
        filePathRow = column.row()
        filePathRow.operator("basepath.open_filebrowser",
                             text="Texture path", icon="FILEBROWSER")
        saveSetting = column.row()
        saveSetting.operator("setting.save", text="Save current setting")

        
        
        if(scene.CheckUVOverLap or scene.CheckUVOverBound or scene.GenerateUvRegardLess):
            uvRow=column.row()
            uvRowSecond=column.row()
            uvRow.prop(
                scene, "UVIslandMargin",text="UV Island Margin")
            uvRow.prop(
                scene, "angleLimit",text="Angle Limit")
            uvRow.prop(
                scene, "areaWeight",text="Area Weight")
            uvRow.prop(
                scene, "scaleToBound",text="scale to bound",toggle=True)
            uvRow.prop(
                scene, "CorrectAspectRatio",text="Correct aspect ratio",toggle=True)
            uvRowSecond.prop(
                scene, "MarginMethod",text="Margin method",toggle=True)
            uvRowSecond.prop(
                scene, "RotateMethod",text="Rotate mthod",toggle=True)
        


        
        if(scene.CustomFolders):
            folderRow = column.row()
            folderRow.prop(
                scene, "FolderTree",text="Folder")
            
            
            
        
        


class Setting_OT_Save(bpy.types.Operator):
    bl_idname = "setting.save"
    bl_label = "Save setting"
    bl_description = f"Save current setting "

    def execute(self, context):
        
        scene = context.scene
        folder = scene.SavedSettingFolder
        tempDictionary = {}
        for setting in scene.settingsNames:
            settingValue = getattr(
                scene, setting)
            tempDictionary[setting] = settingValue
        tempDictionary["MaterialName"]=context.scene.MaterialName

        tempDictionary["compression"]=context.scene.compression
        tempDictionary["quality"]=context.scene.quality
        tempDictionary["exrCodec"]=context.scene.exrCodec
        tempDictionary["tiffCodec"]=context.scene.tiffCodec
        tempDictionary["MaterialName"]=context.scene.MaterialName
        tempDictionary["UVIslandMargin"]=context.scene.UVIslandMargin
        tempDictionary["angleLimit"]=context.scene.angleLimit
        tempDictionary["areaWeight"]=context.scene.areaWeight
        tempDictionary["scaleToBound"]=context.scene.scaleToBound
        tempDictionary["CorrectAspectRatio"]=context.scene.CorrectAspectRatio
        tempDictionary["settingName"]=context.scene.settingName
        tempDictionary["MarginMethod"]=context.scene.MarginMethod
        tempDictionary["RotateMethod"]=context.scene.RotateMethod
        tempDictionary["CopyMaterial"]=context.scene.CopyMaterial
        tempDictionary["CollapseSlot"]=context.scene.CollapseSlot
        
        
        
        

        os.makedirs("folder", exist_ok=True)
        with open(f"{folder}/{scene.settingName}.json", "w") as jsonFile:
            json.dump(tempDictionary, jsonFile)
        scene.SavedSettings = f"{folder}/{scene.settingName}.json"
        return {'FINISHED'}


class OT_BasePath(bpy.types.Operator, ImportHelper):
    bl_idname = "basepath.open_filebrowser"
    bl_label = "Select"
    filter_glob: bpy.props.StringProperty(
        default='',
        options={'HIDDEN'})
    bl_description = "Select the base folder for saving baked texture"

    def execute(self, context):
        context.scene.basePath = os.path.dirname(self.filepath) + os.sep
        return {'FINISHED'}
class DeleteJson_OT_Path(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "Delete.path"
    bl_label = "Delete Path Operator"


    def execute(self, context):
        jsonExportPath=f"{context.scene.basePath}MappingFile/mapping.json"
        if os.path.exists(jsonExportPath):
            os.remove(jsonExportPath)
        return {'FINISHED'}

def GetExrCode(self, context):
    scene = context.scene
    halfBit=[("B44", "B44", "B44"), ("B44A", "B44A", "B44A"), ("DWAA", "DWAA", "DWAA"),("DWAB","DWAB","DWAB") ,("NONE", "NONE", "NONE"),("PIZ", "PIZ", "PIZ"),("PXR24", "PXR24", "PXR24"),("RLE", "RLE", "RLE"),("ZIP", "ZIP", "ZIP"),("ZIPS", "ZIPS", "ZIPS")]
    fullBit=[("DWAA", "DWAA", "DWAA"),("DWAB","DWAB","DWAB") ,("NONE", "NONE", "NONE"),("PIZ", "PIZ", "PIZ"),("PXR24", "PXR24", "PXR24"),("RLE", "RLE", "RLE"),("ZIP", "ZIP", "ZIP")]
    if(scene.float):
        return fullBit
    else:
        return halfBit

listOfClass = [SETTING_PT_PANEL, OT_BasePath, Setting_OT_Save]
class_register, class_unregister = bpy.utils.register_classes_factory(
    listOfClass)


def RegisterSettingTab():
    class_register()
    settingPropertyRegister()


def settingPropertyRegister():
    bpy.types.Scene.tiffCodec= bpy.props.EnumProperty(name="File format", description="What file formate to use", items={
        ("DEFLATE", "DEFLATE", "DEFLATE"), ("LZW", "LZW", "LZW"), ("NONE", "NONE", "NONE"),("PACKBITS","PACKBITS","PACKBITS")})
    bpy.types.Scene.MarginMethod= bpy.props.EnumProperty(name="Margin method", description="Margin method for smart uv project", items={
        ("FRACTION", "FRACTION", "FRACTION"), ("ADD", "ADD", "ADD"), ("SCALED", "SCALED", "SCALED")})
    bpy.types.Scene.RotateMethod= bpy.props.EnumProperty(name="Rotate method", description="Rotate method for smart uv project", items={
        ("AXIS_ALIGNED", "AXIS_ALIGNED", "AXIS_ALIGNED"), ("AXIS_ALIGNED_X", "AXIS_ALIGNED_X", "AXIS_ALIGNED_X"), ("AXIS_ALIGNED_Y", "AXIS_ALIGNED_Y", "AXIS_ALIGNED_Y")})
    bpy.types.Scene.exrCodec= bpy.props.EnumProperty(name="File format", description="What file formate to use", items=GetExrCode)
    bpy.types.Scene.compression=bpy.props.IntProperty(name="Compression",max=100,min=0)
    bpy.types.Scene.quality=bpy.props.IntProperty(name="Compression",max=100,min=0)
    bpy.types.Scene.settingName = bpy.props.StringProperty(
        name="preset", default="Setting1", description="Enter the name of current setting to be saved")
    bpy.types.Scene.margin = bpy.props.IntProperty(
        name="Texture margin", default=16, description="Margin for the texture", min=0, max=64)
    bpy.types.Scene.angleLimit = bpy.props.FloatProperty(
        name="Angle limit", default=0, description="Angle limit for smart uv project", min=0, max=89)
    bpy.types.Scene.scaleToBound = bpy.props.BoolProperty(
        name="Scale to bound", default=False, description="Scale to bound for smart uv project")
    bpy.types.Scene.CorrectAspectRatio = bpy.props.BoolProperty(
        name="Correct aspect ratio", default=False, description="Correct aspect ratio for smart uv project")
    bpy.types.Scene.areaWeight = bpy.props.FloatProperty(
        name="Angle limit", default=0, description="Angle limit for smart uv project", min=0, max=1)
    bpy.types.Scene.height = bpy.props.IntProperty(
        name="Texture Height", default=1024, description="Height of texture", min=1024,step=1024)
    bpy.types.Scene.width = bpy.props.IntProperty(
        name="Texture Width", default=1024, description="Width of texture", min=1024,step=1024)
    bpy.types.Scene.sampling = bpy.props.IntProperty(
        name="sampling", default=1, description="sampling to for bake", min=1,step=4096)
    bpy.types.Scene.extrusion = bpy.props.FloatProperty(
        name="Extrusion", default=0, description="Extrusion to use for baking selected to active", min=0, max=1)
    bpy.types.Scene.rayDistance = bpy.props.FloatProperty(
        name="Ray distance", default=0, description="Raydistance to use for baking selected to active", min=0, max=1)
    bpy.types.Scene.SavedSettings = bpy.props.EnumProperty(
        name="Saved settings", description="Settings", items=getSavedSetting, update=ApplyCurrentSetting)
    bpy.types.Scene.float=bpy.props.BoolProperty(name="Higher Color depth",default=False,description="32-bit for EXR, 16-bit for PNG, and 16-bit for TIFF.")
    bpy.types.Scene.CustomFolders=bpy.props.BoolProperty(name="Custom folders",default=False,description="Use custome folder structure for saving textures")
    bpy.types.Scene.ShadeSmooth = bpy.props.BoolProperty(
        name="Shade Smooth", default=False, description="Turn this on to shade smooth")
    bpy.types.Scene.MaterialName = bpy.props.StringProperty(
        name="New Material Name", default="", description="Specify the name and use the following notation for dynamic value\n[obj]=Mesh name\n[mat]=current mat name\n Leaving this field empty will use the material's name and add an incrementing number at the end if necessary")
    bpy.types.Scene.FolderTree = bpy.props.StringProperty(
        name="folder tree", default="/[mat]", description="Specify the folder structure and use the following notation for dynamic value\n[obj]=Object name\n[bakeType]=name of bake type\n[mat]=material name \n /=new folder")
    bpy.types.Scene.BakeRegardless = bpy.props.BoolProperty(
        name="Bake Regardless", default=False, description="Turn this on to bake texture even if it's not necessary")
    bpy.types.Scene.BakeMulitpleSlots = bpy.props.BoolProperty(
        name="Bake Mulitple Slots", default=False, description="Turn this on to bake multiple slots")
    bpy.types.Scene.CheckUVOverLap = bpy.props.BoolProperty(
        name="Check UV Over Lap", default=False, description="Turn this on to check if the uv is overlapping")
    bpy.types.Scene.CollapseSlot = bpy.props.BoolProperty(
        name="Collapse Slot", default=False, description="Collapse all the slot into one material")
    bpy.types.Scene.CheckUVOverBound = bpy.props.BoolProperty(
        name="Check UV Over Bound", default=False, description="Turn this on to check if the uv is over bound(uv is not within 0-1 space)")
    bpy.types.Scene.GenerateUvRegardLess = bpy.props.BoolProperty(
        name="Generate Uv Regardless", default=False, description="Turn this on to generate uv even if it's not necessary")
    bpy.types.Scene.BakeMultiple = bpy.props.BoolProperty(
        name="Bake Multiple object", default=False, description="Turn this on to bake multiple object")
    bpy.types.Scene.fakeUser = bpy.props.BoolProperty(
        name="Fake user", default=False, description="Enable Fake user")
    bpy.types.Scene.UseUdims = bpy.props.BoolProperty(
        name="Use Udims", default=False, description="Turn this on to use udims automatically")
    bpy.types.Scene.FileFormat = bpy.props.EnumProperty(name="File format", description="What file formate to use", items={
        ("png", "png", "Save texture as png"), ("tga", "tga", "Save texture as tga"), ("exr", "exr", "Save texture as exr"),("tiff","tiff","Save texture as tiff") ,("jpg", "jpg", "Save texture as jpg")})
    bpy.types.Scene.BakedImagesFilePath = "All Baked Images"
    bpy.types.Scene.PreBakedFilePath = "All Pre Baked Images"
    bpy.types.Scene.Device = bpy.props.EnumProperty(name="Device", description="Device to use for baking", items={
        ("GPU", "GPU", "Use gpu for baking"), ("CPU", "CPU", "Use cpu for baking")})
    bpy.types.Scene.CopyNodeGroup = bpy.props.BoolProperty(
        name="Copy Node Group", default=False, description="Turn this on to copy node group")
    bpy.types.Scene.ApplyMaterial = bpy.props.BoolProperty(
        name="Apply Material", default=False, description="Turn this on to apply the material")
    bpy.types.Scene.CopyMaterial = bpy.props.BoolProperty(
        name="Copy material", default=True, description="turn this on to copy material before baking", update=SetCopiedMaterialDefault)
    bpy.types.Scene.AntialiasingScale = bpy.props.FloatProperty(
        name="Anti aliasing", description="Less then 1 does downscaling, greater then 1 does upscaling,and at 1 does nothing", default=1, min=0.1, max=2)
    bpy.types.Scene.UVIslandMargin = bpy.props.FloatProperty(
        name="UV Island Margin", description="UV Island Margin for smart uv project", min=0)
    bpy.types.Scene.AllowInverted = bpy.props.BoolProperty(
        name="Allow Inverted", default=False, description="Turn this on to avoid detecting texture with inverted channel as procedual")
    bpy.types.Scene.AllowChannelPacking = bpy.props.BoolProperty(
        name="Allow Channel", default=False, description="Turn this on to avoid detecting texture with channel packing as procedual")

def UnregisterSettingTab():
    class_unregister()
    
    del bpy.types.Scene.packObject
    settingPropertyUnregister()


def settingPropertyUnregister():
    del bpy.types.Scene.AllowInverted
    del bpy.types.Scene.AllowChannelPacking
    del bpy.types.Scene.settingName 
    del bpy.types.Scene.margin 
    del bpy.types.Scene.height 
    del bpy.types.Scene.extrusion
    del bpy.types.Scene.rayDistance
    del bpy.types.Scene.SavedSettings 
    del bpy.types.Scene.width 
    del bpy.types.Scene.ShadeSmooth
    del bpy.types.Scene.MaterialName
    del bpy.types.Scene.FolderTree 
    del bpy.types.Scene.BakeRegardless 
    del bpy.types.Scene.BakeMulitpleSlots
    del bpy.types.Scene.CheckUVOverLap 
    del bpy.types.Scene.CheckUVOverBound 
    del bpy.types.Scene.GenerateUvRegardLess 
    del bpy.types.Scene.BakeMultiple
    del bpy.types.Scene.UseUdims 
    del bpy.types.Scene.FileFormat 
    del bpy.types.Scene.BakedImagesFilePath 
    del bpy.types.Scene.PreBakedFilePath 
    del bpy.types.Scene.Device 
    del bpy.types.Scene.CopyNodeGroup 
    del bpy.types.Scene.ApplyMaterial
    del bpy.types.Scene.CopyMaterial 
    del bpy.types.Scene.AntialiasingScale 
    del bpy.types.Scene.UVIslandMargin 

