class PackedTexture:
    texture:set[str]=set()