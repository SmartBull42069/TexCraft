from .Core import Start
import bpy
from .Category import Catergory
class MAIN_PT_PANEL(bpy.types.Panel):
    bl_label = "Main"
    bl_idname = "SCENE_PT_Main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = Catergory.GetCategory()

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.operator("Main.now",text="Start")
class Main_OT_Now(bpy.types.Operator):
    bl_idname = "main.now"
    bl_label = "main Operator"
    bl_description = "Click Start"
    @classmethod
    def poll(cls,context):
        
        return context.mode=="OBJECT" and bpy.context.area.ui_type == 'VIEW_3D'

    def execute(self, context):
        if(bpy.context.scene.basePath==""):
            if(bpy.path.abspath("//")!=""):
                bpy.context.scene.basePath=bpy.path.abspath("//")
            else:
                bpy.ops.warning.path()
                return {'FINISHED'}
        Start()
        return {'FINISHED'}
    
    
class Warning_OT_Path(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "warning.path"
    bl_label = "Warning Path Operator"


    def execute(self, context):
        self.report({'ERROR'}, 'Please select texture path')
        return {'FINISHED'}

class No_OT_Uv(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "no.uv"
    bl_label = "no uv Operator"


    def execute(self, context):
        self.report({'ERROR'}, 'Please select uv')
        return {'FINISHED'}

listOfClass = [Warning_OT_Path,Main_OT_Now, MAIN_PT_PANEL,No_OT_Uv]
class_register, class_unregister = bpy.utils.register_classes_factory(
    listOfClass)


def registerStartTab():
    class_register()

def UnregisterStartTab():
    class_unregister()