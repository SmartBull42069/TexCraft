from bpy.types import Material,NodeTree,Image
from typing import Set
import bpy

class TrashData:
    nodeGroups:Set[NodeTree]=set()
    materials:Set[Material]=set()
    images:Set[Image]=set()
    matName:dict[Material,str]={}
    cleanedMat:set[Material]=set()
    @staticmethod
    def Delete():
        for nodeGroup in reversed(list(TrashData.nodeGroups)):
            try:
                bpy.data.node_groups.remove(nodeGroup)
            except:
                pass
        for material in reversed(list(TrashData.materials)):
            try:
                bpy.data.materials.remove(material)
            except:
                pass
        for image in reversed(list(TrashData.images)):
            try:
                bpy.data.images.remove(image)
            except:
                pass
        for material in TrashData.matName:
            try:
                material.name=TrashData.matName[material]
            except:
                pass
        TrashData.nodeGroups=set()
        TrashData.materials=set()
        TrashData.images=set()
    def DeletePartial():
        for material in reversed(list(TrashData.cleanedMat)):
            try:
                bpy.data.materials.remove(material)
            except:
                pass
        TrashData.cleanedMat=set()
