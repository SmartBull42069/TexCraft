class Catergory:
    name:str="TexCraft"
    def GetCategory():
        return Catergory.name