
import tomllib
class Catergory:
    name:str=""
    def GetCategory():
        if(Catergory.name==""):
            with open("./blender_manifest.toml","rb") as toml:
                data = tomllib.load(toml)
                Catergory.name= data["name"]
        return Catergory.name