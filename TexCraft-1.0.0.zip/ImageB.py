import bpy
from bpy.types import Image,Material,ShaderNodeTexImage,ShaderNodeSeparateColor
from .Name import Name
import os
from .SaveSetting import SaveSetting
from typing import Union
import os
from .Connection import Connection
class ImageB:
    def __init__(self,matName:str, udimCount:Union[list[int],None],meshName:str, imageObj,path:Union[str,None]=None,useAlpha=False,image:Union[Image,None]=None,loadTiled:bool=False):
        self.bakeType:str=imageObj.name
        self.textureNodes:dict[Material,ShaderNodeTexImage]={}
        self.seperateNodes:dict[ShaderNodeTexImage,ShaderNodeSeparateColor]={}
        self.preFilePath:Union[str,dict[int,str]]=None
        self.filePath:Union[str,dict[int,str]]=None
        self.matName:str=matName
        self.meshName:str=meshName
        self.inverted:bool=False
        self.scaled:bool=False
        self.space=imageObj.space
        

        if(path==None and image==None):
            self.name:str=Name.GetImageName(matName, meshName, imageObj)
            self.image:Image = bpy.data.images.new(
            self.name, round(bpy.context.scene.height*bpy.context.scene.AntialiasingScale), round(bpy.context.scene.width*bpy.context.scene.AntialiasingScale), float_buffer=bpy.context.scene.float, alpha=useAlpha, tiled=udimCount !=None)
            
            if (udimCount!=None):
                with bpy.context.temp_override(**{'edit_image': self.image}):
                    for i in udimCount:
                        bpy.ops.image.tile_add(
                        number=i, generated_type="BLANK", alpha=False, float=bpy.context.scene.float, fill=True)
            self.tiles:Union[list[int],None]=udimCount
        elif(image!=None):
            self.image=image
            self.name=self.image.name
            if(self.image.source=="TILED"):
                self.tiles:Union[list[int],None]=[]
                for tile in self.image.tiles:
                    self.tiles.append(tile.number)
                self.image.name=self.name
            else:
                self.tiles:Union[list[int],None]=None
        else:
            self.image:Image=bpy.data.images.load(
            path, check_existing=True)
            self.name="".join(os.path.splitext(os.path.basename(self.image.name))[:-1])
            if(loadTiled):
                self.image.source="TILED"
            if(self.image.source=="TILED"):
                self.tiles:Union[list[int],None]=[]
                for tile in self.image.tiles:
                    self.tiles.append(tile.number)
                self.image.name=self.name
            else:
                self.tiles:Union[list[int],None]=None
        self.image.use_fake_user=bpy.context.scene.fakeUser
        self.image.colorspace_settings.name = imageObj.space
        self.image.name=self.name
        
    def GetFilePath(self,isPreBaked: bool, tileInfo):
        if(isPreBaked and self.preFilePath):
            if(isinstance(tileInfo, int)):
                return self.preFilePath[tileInfo]
            elif(tileInfo==None):
                return self.preFilePath
        elif((not isPreBaked) and self.filePath):
            if(isinstance(tileInfo, int)):
                return self.filePath[tileInfo]
            elif(tileInfo==None):
                return self.filePath
            
        subFolder: str = bpy.context.scene.FolderTree
        if (subFolder[0] != "/"):
            subFolder = "/"+subFolder
        subFolder = subFolder.replace("[mat]", self.matName)
        subFolder = subFolder.replace("[bakeType]", self.bakeType)
        subFolder = subFolder.replace("[obj]", self.meshName)
        filePath = bpy.context.scene.basePath + \
            bpy.context.scene.BakedImagesFilePath
        preBakedFilePath = bpy.context.scene.basePath + \
            bpy.context.scene.PreBakedFilePath
        if (isPreBaked):
            pathToUseDir = preBakedFilePath + subFolder
        else:
            pathToUseDir = filePath + subFolder
        extension = bpy.context.scene.FileFormat
        if (self.image.source=="TILED"):
            imageFile = f"{pathToUseDir}/" + \
                f"{self.name}.{tileInfo}.{extension}"
        else:
            imageFile = f"{pathToUseDir}/" + \
                f"{self.name}.{extension}"  
        os.makedirs(os.path.normpath(os.path.dirname(imageFile)), exist_ok=True)
        return imageFile
    def Reload(self,isPrebaked):
        if(isPrebaked):
            if(self.tiles!=None):
                self.image=bpy.data.images.load(filepath=self.preFilePath[list(self.preFilePath.keys())[0]])
                self.image.source="TILED"
            else:
                self.image=bpy.data.images.load(filepath=self.preFilePath)
        else:
            if(self.tiles!=None):
                self.image=bpy.data.images.load(filepath=self.filePath[list(self.preFilePath.keys())[0]])
                self.image.source="TILED"
            else:
                self.image=bpy.data.images.load(filepath=self.filePath)
        self.image.use_fake_user=bpy.context.scene.fakeUser
        self.image.colorspace_settings.name = self.space
        self.image.name=self.name
    def SaveImage(self,isPreBaked: bool):
        
        imageFile = self.GetFilePath(isPreBaked, "<UDIM>")
        
        SaveSetting.SetSettings(self)
        
        self.image.filepath_raw=imageFile
        with bpy.context.temp_override(**{'edit_image': self.image}):
            bpy.ops.image.save()
        if (self.image.source == "TILED"):
            imagesPath = {}
            for tile in self.image.tiles:
                path:str=self.GetFilePath(isPreBaked,f"{tile.number}")
                imagesPath[tile.number] = path
            if(isPreBaked):
                self.preFilePath=imagesPath
            elif((not isPreBaked)):
                self.filePath=imagesPath
        else:
            if(isPreBaked):
                self.preFilePath=imageFile
            elif((not isPreBaked)):
                self.filePath=imageFile
        self.image.update()
        

    def AddImageNode(self,mat: Material) -> ShaderNodeTexImage:
        if(mat in self.textureNodes):
            return self.textureNodes[mat]
        imageTexture: ShaderNodeTexImage = mat.node_tree.nodes.new(
            type="ShaderNodeTexImage")
        self.textureNodes[mat]=imageTexture
        self.SelectNode(mat)
        imageTexture.image = self.image
        return imageTexture
    

    def AddSeperateNode(self,node: ShaderNodeTexImage,mat:Material) -> ShaderNodeSeparateColor:
        if(node in self.seperateNodes):
            return self.seperateNodes[node]
        seperateNode: ShaderNodeSeparateColor = mat.node_tree.nodes.new(
            type="ShaderNodeSeparateColor")
        self.seperateNodes[node]=seperateNode
        Connection.CreateLink(mat,seperateNode,node.outputs["Color"],"Color")
        return seperateNode
    
    def SelectNode(self,mat:Material):
        if(mat in self.textureNodes):
            for node in mat.node_tree.nodes:
                node.select=False
            self.textureNodes[mat].select=True
            mat.node_tree.nodes.active=self.textureNodes[mat]

            
    def GetPaths(self,prebake:bool):
        if(prebake):
            return[self.image, self.preFilePath, self.image.source == "TILED"]
        return  [self.image, self.filePath, self.image.source == "TILED"]
    

