import bpy


class SaveSetting:
    @staticmethod
    def SetSettings(image):
        settings = bpy.context.scene.render.image_settings
        fileFormat=bpy.context.scene.FileFormatBpy[bpy.context.scene.FileFormat]
        image.image.file_format=fileFormat
        bpy.context.scene.sequencer_colorspace_settings.name = image.image.colorspace_settings.name
        settings.file_format = fileFormat
        if(image.bakeType in bpy.context.scene.greyScale):
            settings.color_mode="BW"
        elif(image.image.channels==3 or bpy.context.scene.FileFormat=="jpg"):
            settings.color_mode="RGB"
        else:
            settings.color_mode="RGBA"
        if(bpy.context.scene.float):
            if(bpy.context.scene.FileFormat=="exr"):
                settings.color_depth="32"
            elif(bpy.context.scene.FileFormat=="png" or bpy.context.scene.FileFormat=="tiff"):
                settings.color_depth="16"
        elif(bpy.context.scene.FileFormat=="png"):
            settings.color_depth="8"
        elif(bpy.context.scene.FileFormat=="exr"):
            settings.color_depth="16"
        if(bpy.context.scene.FileFormat=="png"):
            settings.compression=bpy.context.scene.compression
        elif(bpy.context.scene.FileFormat=="jpg"):
            settings.compression=bpy.context.scene.quality
        elif(bpy.context.scene.FileFormat=="exr"):
            if(bpy.context.scene.exrCodec==""):
                settings.exr_codec="NONE"
            else:
                settings.exr_codec=bpy.context.scene.exrCodec
        elif(bpy.context.scene.FileFormat=="tiff"):
            settings.tiff_codec=bpy.context.scene.tiffCodec