import bpy
from typing import List
from bpy.types import Object,Modifier,UVLoopLayers, Material, Node, NodeSocket, ShaderNodeTexImage, Image,  MeshUVLoopLayer, bpy_prop_array, ShaderNodeSeparateColor,NodeSocketShader
import mathutils
import math
import os
import itertools
import json
import numpy
from .Enums import InputStatus
from .Enums import Channel
from .ObjMatSet import ObjectData
from .TrashData import TrashData
from .Name import Name
from .ImageB import ImageB
from .UvManager import UvManager
from .PackedTexture import PackedTexture
from .Connection import Connection
def DeleteUnusedNode(mat:Material):
    nodesToDel:set[Node]=set()
    furthurMat:set[Node]=set()
    nodesToCheck:set[Node]=set()
    currentMat:Material=mat
    for node in currentMat.node_tree.nodes:
        nodesToCheck.add(node)
    while len(nodesToCheck)>0:
        convertedNodesToCheck=list(nodesToCheck)
        for node in convertedNodesToCheck:
            if(node.bl_idname!="ShaderNodeOutputMaterial" and node.bl_idname!="NodeGroupOutput" and node.bl_idname!="NodeGroupInput" and node.bl_idname!="ShaderNodeGroup"):
                canDelete=True
                for outputs in node.outputs:
                    if(outputs.is_linked):
                        canDelete=False
                if(canDelete):
                    nodesToDel.add(node)
            elif(node.bl_idname=="ShaderNodeGroup"):
                furthurMat.add(node)
        nodesToCheck.clear()
        reversedNodeList=reversed(list(nodesToDel))
        for node in reversedNodeList:
            for input in node.inputs:
                if(input.is_linked):
                    for link in input.links:
                        nodesToCheck.add(link.from_node)
            try:
                currentMat.node_tree.nodes.remove(node)
            except:
                pass
        nodesToDel.clear()
        if(len(furthurMat)>1):
            convertedFurthurMat=list(furthurMat)
            currentMat=convertedFurthurMat[0]
            convertedFurthurMat.pop(0)
            furthurMat=set(convertedFurthurMat)
            for node in currentMat.node_tree.nodes:
                nodesToCheck.add(node)

def GetNeedColorRamp(mats: Material, bakeType, outPutSocket: NodeSocket):
    if (bakeType in bpy.context.scene.bakeTypeColorRamp):
        node = mats.node_tree.nodes.new(type="ShaderNodeValToRGB")
        for position, positionValue in enumerate(bpy.context.scene.bakeTypeColorRamp[bakeType]["Positions"]):
            node.color_ramp.elements[position].position = positionValue
        Connection.CreateLink(mats, node, outPutSocket, "Fac")
        return [node.outputs["Color"],node]
    return False


def GetNodeSocketFromRequire(mat: Material, bakeTypeInformation: str) -> NodeSocket:
    newNode = mat.node_tree.nodes.new(type=bakeTypeInformation["Node"])
    for properties, inputs in itertools.zip_longest(bakeTypeInformation["Properties"], bakeTypeInformation["Inputs"], fillvalue="Empty"):
        if (properties != "Empty"):
            setattr(newNode, properties,
                    bakeTypeInformation["Properties"][properties])
        if (inputs != "Empty"):
            Connection.CreateLink(mat, newNode,
                      bakeTypeInformation["Inputs"][inputs], inputs)
    return [newNode.outputs[bakeTypeInformation["OutPutSocket"]],newNode]


def PreBakeTypeCheck(input: NodeSocket):

    inputSocketToCheck: NodeSocket = input
    nodeTocheck: Node = input.node
    returnDefaultZero: bool = False
    
    if (input.is_linked):
        nodeTocheck: Node = input.links[0].from_node
        inputNodeSocketInfor = bpy.context.scene.giveInputSocket
        if (nodeTocheck.type in inputNodeSocketInfor):
            inputSocketToCheck = nodeTocheck.inputs[inputNodeSocketInfor[
                nodeTocheck.type]]
    dependantProperty = bpy.context.scene.propertyWithDependants
    if ((nodeTocheck.type in dependantProperty) and (inputSocketToCheck.name in dependantProperty[nodeTocheck.type])):
        for propertyObject in dependantProperty[nodeTocheck.type][inputSocketToCheck.name]:
            for propertyKey in propertyObject:
                if (type(nodeTocheck.inputs[propertyKey].default_value) == bpy_prop_array):
                    if ((nodeTocheck.inputs[propertyKey].default_value[:] == propertyObject[propertyKey]) and (nodeTocheck.inputs[propertyKey].is_linked == False)):
                        returnDefaultZero = True
                else:
                    if ((nodeTocheck.inputs[propertyKey].default_value == propertyObject[propertyKey]) and (nodeTocheck.inputs[propertyKey].is_linked == False)):
                        returnDefaultZero = True
    if (returnDefaultZero):
        value = input.node.inputs[input.name].default_value
        if (type(value) == bpy_prop_array):
            return [InputStatus.DEFAULT, (0,)*len((input.node.inputs[input.name].default_value[:])),Channel.FULL]
        else:
            return [InputStatus.DEFAULT, 0,Channel.FULL]
    return BakeType(inputSocketToCheck)


def BakeType(input: NodeSocket):
    channel=Channel.FULL
    value = input.node.inputs[input.name].default_value
    if (input.is_linked == False):
        if( type(value) == float or type(value) == int):
            return [InputStatus.DEFAULT, input.node.inputs[input.name].default_value,channel]
        else:
            return [InputStatus.DEFAULT, (input.node.inputs[input.name].default_value[:]),channel]
    ConnectedNode:Node = input.links[0].from_node
    
    if(ConnectedNode.type == "INVERT" and bpy.context.scene.AllowInverted):
        if(ConnectedNode.inputs[1].is_linked):
            input=ConnectedNode.inputs[1].links[0].to_socket
            ConnectedNode=ConnectedNode.inputs[1].links[0].from_node
    if(ConnectedNode.type=="SEPARATE_COLOR" and bpy.context.scene.AllowChannelPacking and ConnectedNode.mode=="RGB"):
        if(ConnectedNode.inputs[0].is_linked):
            ConnectedNode=ConnectedNode.inputs[0].links[0].from_node
            if(input.links[0].from_socket.name=="Red"):
                channel=Channel.RED
            elif(input.links[0].from_socket.name=="Blue"):
                channel=Channel.BLUE
            elif(input.links[0].from_socket.name=="Green"):
                channel=Channel.GREEN
    
    if(ConnectedNode.type=="COMBINE_COLOR" and bpy.context.scene.AllowInverted):
        lastConnectedNode=None
        for i in ConnectedNode.inputs:
            if(i.is_linked):
                if(lastConnectedNode==None):
                    if(i.links[0].from_node.type=="INVERT"):
                        if(not (i.links[0].from_node.inputs[1].is_linked and i.links[0].from_node.inputs[1].links[0].from_node.type=="SEPARATE_COLOR")):
                            return [InputStatus.PROCEDUAL]
                        else:
                            lastConnectedNode=i.links[0].from_node.inputs[1].links[0].from_node
                    else:
                        lastConnectedNode=i.links[0].from_node
                elif(i.links[0].from_node!=lastConnectedNode):
                    if(not(i.links[0].from_node.type=="INVERT" and i.links[0].from_node.inputs[1].is_linked and (i.links[0].from_node.inputs[1].links[0].from_node==lastConnectedNode or lastConnectedNode==None))):
                        return [InputStatus.PROCEDUAL]
        if(lastConnectedNode!=None):
            ConnectedNode=lastConnectedNode
        else:
            if (type(value) == bpy_prop_array):
                return [InputStatus.DEFAULT, (0,)*len((input.node.inputs[input.name].default_value[:])),channel]
            else:
                return [3, 0,channel]
        ConnectedNode=lastConnectedNode
    if(ConnectedNode.type=="SEPARATE_COLOR" and bpy.context.scene.AllowInverted):
        if(ConnectedNode.inputs[0].is_linked):
            ConnectedNode=ConnectedNode.inputs[0].links[0].from_node


    if ((ConnectedNode.type == "TEX_IMAGE") and (not ConnectedNode.inputs["Vector"].is_linked)):
        if (ConnectedNode.image == None):
            if (type(value) == bpy_prop_array):
                return [InputStatus.DEFAULT, (0,)*len((input.node.inputs[input.name].default_value[:])),channel]
            else:
                return [3, 0,channel]
        else:
            if(ConnectedNode.outputs[0].name!="Color"):
                channel==Channel.ALPHA
            return [InputStatus.TEXTURE, ConnectedNode,channel]
    return [InputStatus.PROCEDUAL]


def CombineUvUdimCheck(uvPointRound: int):
    bpy.ops.object.select_all(action="DESELECT")
    udimTiles = {}
    useUdim = {}
    useUv = {}
    for obj in bpy.context.scene.my_items:
        mesh = obj.mesh
        useUdim[mesh] = False
        if (bpy.context.scene.GenerateUvRegardLess):
            useUv[mesh] = True
        else:
            useUv[mesh] = False
        tempUdims = []
        mesh.select_set(True)
        bpy.context.view_layer.objects.active = mesh
        uv = mesh.data.uv_layers.active
        if ((bpy.context.scene.UseUdims) and (useUv[mesh] == False)):
            for i in uv.data:
                vector: mathutils.Vector = i.uv
                if (bpy.context.scene.CheckUVOverBound):
                    if ((0 > round(vector.x, uvPointRound)) or (0 > round(vector.y, uvPointRound))):

                        useUv[mesh] = True
                        break
                if ((vector.x >= 0) and (vector.y >= 0)):
                    xCor = math.ceil(round(vector.x, uvPointRound))-1
                    yCor = (math.ceil(round(vector.y, uvPointRound))-1)*10
                    if (xCor < 1):
                        xCor = 0
                    if (yCor < 1):
                        yCor = 0
                    udimToAdd = 1001+yCor+xCor
                    if (udimToAdd != 1001):
                        useUdim[mesh] = True
                    tempUdims.append(udimToAdd)
        if ((bpy.context.scene.CheckUVOverBound) and (bpy.context.scene.UseUdims == False)):
            for i in uv.data:
                vector: mathutils.Vector = i.uv
                if ((0 > round(vector.x, uvPointRound)) or (round(vector.x, uvPointRound) > 1) or (0 > round(vector.y, uvPointRound)) or (round(vector.y, uvPointRound) > 1)):
                    useUv[mesh] = True
        if(useUdim[mesh]==False):
            udimTiles[mesh]=None
        else:
            udimTiles[mesh] = list(set(tempUdims))
        if (not bpy.context.scene.BakeMultiple):
            bpy.ops.object.select_all(action="DESELECT")
    if (bpy.context.scene.CheckUVOverLap):
        if (bpy.context.scene.BakeMultiple):
            for obj in bpy.context.scene.my_items:
                mesh = obj.mesh
                mesh.select_set(True)
                bpy.context.view_layer.objects.active = mesh
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.context.scene.tool_settings.use_uv_select_sync = True
            bpy.ops.uv.select_overlap()
            for obj in bpy.context.scene.my_items:
                mesh = obj.mesh
                if (mesh.data.total_face_sel > 0):
                    useUv[mesh] = True
            bpy.ops.object.mode_set(mode="OBJECT")
        else:
            for obj in bpy.context.scene.my_items:
                mesh = obj.mesh
                mesh.select_set(True)
                bpy.context.view_layer.objects.active = mesh
                bpy.ops.object.mode_set(mode="EDIT")
                bpy.context.scene.tool_settings.use_uv_select_sync = True
                bpy.ops.uv.select_overlap()
                if (mesh.data.total_face_sel > 0):
                    useUv[mesh] = True
                bpy.ops.object.mode_set(mode="OBJECT")
        
    return [udimTiles, useUv]


def CreateUv(useUv: bool) -> List[MeshUVLoopLayer]:
    meshListWithUv = {}
    bpy.ops.object.select_all(action="DESELECT")

    for obj in bpy.context.scene.my_items:
        mesh: Object = obj.mesh
        if (not useUv[mesh] or len(mesh.data.uv_layers)>=8):
            meshListWithUv[mesh]= mesh.data.uv_layers[obj.uv]
        else:
            New_Uv_map: MeshUVLoopLayer = mesh.data.uv_layers.new(
                name=f"{mesh.name}_UV")
            obj.uv= New_Uv_map.name
            mesh.data.uv_layers[New_Uv_map.name].active = True
            mesh.data.uv_layers[New_Uv_map.name].active_render = True
            bpy.context.view_layer.objects.active = mesh
            mesh.select_set(True)
            meshListWithUv[mesh] = New_Uv_map
            if (not (bpy.context.scene.BakeMultiple and any(list(useUv.values())))):
                GenerateUv(meshListWithUv)
                bpy.ops.object.select_all(action="DESELECT")
    if (bpy.context.scene.BakeMultiple and any(list(useUv.values()))):
        GenerateUv(meshListWithUv)


def GenerateUv(meshListWithUv):
    bpy.context.scene.tool_settings.use_uv_select_sync = True
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(angle_limit=math.radians(
        bpy.context.scene.angleLimit), island_margin=bpy.context.scene.UVIslandMargin,
        area_weight=bpy.context.scene.areaWeight,scale_to_bounds=bpy.context.scene.scaleToBound,
        correct_aspect=bpy.context.scene.CorrectAspectRatio,margin_method=bpy.context.scene.MarginMethod,rotate_method=bpy.context.scene.RotateMethod)
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.context.scene.tool_settings.use_uv_select_sync = False
    
    for mesh in meshListWithUv:
        mesh.data.uv_layers[meshListWithUv[mesh].name].active = True
        mesh.data.uv_layers[meshListWithUv[mesh].name].active_render = True
    


def RemoveAndSetUv(mesh: Object, uvMap: MeshUVLoopLayer) -> None:
    uvs: List[UVLoopLayers] = [
        uv.name for uv in mesh.data.uv_layers if uv.name != uvMap.name]
    if (mesh.data.uv_layers[uvMap.name].active_render != True):
        mesh.data.uv_layers[uvMap.name].active_render = True
    if (mesh.data.uv_layers.active != uvMap):
        mesh.data.uv_layers[uvMap.name].active = True
    for uv in uvs:
        mesh.data.uv_layers.remove(
            mesh.data.uv_layers.get(uv))

def GetUnpackedMateria(mats:Material,num,obj:Object,revertMaterials):
    bpy.ops.object.select_all(action="DESELECT")
    bpy.context.view_layer.objects.active = obj
    bpy.context.object.active_material_index = num
    
    copiedMat=mats.copy()
    obj.material_slots[num].material = copiedMat
    spaces = [copiedMat]
    numberOfSpaces=0
    copiedMat.name=f"unpackedMat {mats.name} {obj.name}"
    for space in spaces:
        for node in space.node_tree.nodes:
            if node.type == 'GROUP':
                spaces.append(node)
                numberOfSpaces+=1
    home_area = bpy.context.area.type
    home_ui = bpy.context.area.ui_type
    bpy.context.area.type = "NODE_EDITOR"
    bpy.context.area.ui_type = "ShaderNodeTree"
    bpy.context.space_data.shader_type = "OBJECT"
    for i in range(numberOfSpaces):
        bpy.ops.node.select_all(action='SELECT')
        bpy.ops.node.group_ungroup()
        bpy.context.view_layer.update()
    bpy.context.area.type = home_area
    bpy.context.area.ui_type = home_ui
    if(revertMaterials):
        obj.material_slots[num].material = mats
    return copiedMat



def GetAllInputNode(mats: Material, NodeType: str, bakeType) -> Node:
    nodeGroupsList: List[Node] = []
    nodeList: List[Node] = []
    nodeList.extend(mats.node_tree.nodes)
    foundNodes = []
    baseBakeInfo = bpy.context.scene.baseNode
    for node in nodeList:
        if (node.type in NodeType):
            if (node.type in baseBakeInfo and (node.outputs[baseBakeInfo[node.type]["Output"]].links[0].to_node.type==node.type)):
                # here maybe
                continue
            
            propertyDependentInput = bpy.context.scene.propertyDependentInput
            if (bakeType in propertyDependentInput and propertyDependentInput[bakeType]["NodeType"] == node.type):
                propertyDependInfo = propertyDependentInput[bakeType]
                if (getattr(node, propertyDependInfo["Property"]) not in propertyDependInfo["PropertyAccept"]):
                    # here maybe
                    continue
            if(bakeType in  bpy.context.scene.requireAdditionalNode):
                tempList=foundNodes.copy()
                added=False
                for items in foundNodes:
                    if (items[1] == mats):
                        tempList.append(
                        [node, mats, items[2]])
                    added=True
                foundNodes = tempList
                if(not added):
                    connectToOutNode = GetNodeSocketFromRequire(
                            mats, bpy.context.scene.requireAdditionalNode[bakeType])
                    newSocket = GetNeedColorRamp(
                            mats, bakeType, connectToOutNode[0])
                    if (newSocket != False):
                            connectToOutNode = newSocket[0]
                    else:
                        connectToOutNode = connectToOutNode[0]
                    foundNodes.append(
                        [node, mats, connectToOutNode])
            else :
                value=GetInputValueRaw(bakeType,node)
                foundNodes.append(
                [node, mats, value])
        elif (type(node) == bpy.types.ShaderNodeGroup):
            nodeGroupsList.append(node)
    for nodeGroup in nodeGroupsList:
        result = GetAllInputNode(nodeGroup, NodeType, bakeType)
        if (result != False):
            foundNodes.extend(result)
    if (foundNodes.__len__() <= 0):
        # here maybe
        return False
    else:
        return foundNodes

def GetNodeMat(mats: Material, NodeType: str, bakeType) -> Node:
    nodeList: List[Node] = []
    nodeList.extend(mats.node_tree.nodes)
    baseBakeInfo = bpy.context.scene.baseNode
    
    for node in nodeList:
        if (node.type in NodeType):
            propertyDependentInput = bpy.context.scene.propertyDependentInput
            if (bakeType in propertyDependentInput and propertyDependentInput[bakeType]["NodeType"] == NodeType):
                propertyDependInfo = propertyDependentInput[bakeType]
                if (getattr(node, propertyDependInfo["Property"]) not in propertyDependInfo["PropertyAccept"]):
                    # here maybe
                    continue
            if (node.type in baseBakeInfo and (node.outputs[baseBakeInfo[node.type]["Output"]].links[0].to_node.type==node.type)):
                # here maybe
                continue
            return [node, mats]
    return False
def GetAllNodeMat(mats: Material, NodeType,bakeType):
    nodeGroupsList: List[Node] = []
    nodeList: List[Node] = []
    nodeList.extend(mats.node_tree.nodes)
    foundNodes = []
    baseBakeInfo = bpy.context.scene.baseNode
    for node in nodeList:
        if (node.type in NodeType):
            if (node.type in baseBakeInfo and (node.outputs[baseBakeInfo[node.type]["Output"]].links[0].to_node.type==node.type)):
                # here maybe
                continue
            propertyDependentInput = bpy.context.scene.propertyDependentInput
            if (bakeType in propertyDependentInput and propertyDependentInput[bakeType]["NodeType"] == node.type):
                propertyDependInfo = propertyDependentInput[bakeType]
                if (getattr(node, propertyDependInfo["Property"]) not in propertyDependInfo["PropertyAccept"]):
                    # here maybe
                    continue
            foundNodes.append(
            [node, mats])
        elif (type(node) == bpy.types.ShaderNodeGroup):
            nodeGroupsList.append(node)
    for nodeGroup in nodeGroupsList:
        result = GetAllNodeMat(nodeGroup, NodeType, bakeType)
        if (result != False):
            foundNodes.extend(result)
    if (foundNodes.__len__() <= 0):
        # here maybe
        return False
    else:
        return foundNodes

def GetAllNode(mats: Material, NodeType,excluded):
    nodeList: List[Node] = []
    nodeList.extend(mats.node_tree.nodes)
    nodeGroupsList = []
    foundNodes = {}
    for node in nodeList:
        if ((node.type in NodeType) and (node not in excluded) and (node.outputs[0].is_linked)):
            foundNodes[node]=mats
    for nodeGroup in nodeGroupsList:
        result = GetAllNode(nodeGroup, NodeType,excluded)
        if (result != False):
            foundNodes.update(result)
    
    if (foundNodes.__len__() > 1):
        return foundNodes
    else:
        # here maybe
        return False




def BakeMap(uv: MeshUVLoopLayer, mesh: Object, bakeType: str, udimCount: list[int],  imageObj, selected, existingImages:dict[str,dict[int,ImageB]]):
    ImageBakeData = {}
    furtherConnectionData = {}
    defaultData = {}
    ogMats={}
    imagesAddedSoFar = []
    baseBakeInfo = bpy.context.scene.baseNode
    BakeInputNodesUnpacked=None
    BakeSelectedInputNodesUnpacked=None
    inputNodeType = bpy.context.scene.inputNode
    inputNodeName = bpy.context.scene.inputNodeNames
    materialOutput=None

    firstBakedImage: ImageB = None
    firstBakedImageSelected: ImageB = None
    previouseState = None

    foundEmptyOne=False
    shoulBake = ((bpy.context.scene.BakeRegardless or selected != None or (bpy.context.scene.BakeMultiple and len(bpy.context.scene.my_items) > 1)) and imageObj.enabled) or (
        bakeType in bpy.context.scene.allwaysRequireBaking)
    
    matLen = mesh.data.materials.__len__()
    for matSlot in range(matLen):
        BakeSelectedInputNodesUnpacked= None
        mat = mesh.data.materials[matSlot]
        ogMats[mat]=[matSlot,mesh]
        unpackedMat=GetUnpackedMateria(mat,matSlot,mesh,False)
        TrashData.cleanedMat.add(unpackedMat)
        DeleteUnusedNode(unpackedMat)
        BakeInputNodesUnpacked = GetAllInputNode(
            unpackedMat, inputNodeType[bakeType], bakeType)
        materialOutput = GetNodeMat(unpackedMat, "OUTPUT_MATERIAL", "Material OutPut Surface")
        nodeListExclude=[]

        
        if (BakeInputNodesUnpacked == False):
            if(not materialOutput):
               materialOutputExclude:Node=materialOutput[0]
               materialOutputMat:Material=materialOutput[1]
               materialOutputMat.node_tree.nodes.remove(materialOutputExclude)
            foundEmptyOne=True
            continue  # here
        if (materialOutput == False):
            foundEmptyOne=True
            continue   # here
        if(foundEmptyOne):
            shoulBake = True
            
        for i in BakeInputNodesUnpacked:
            if(i[0].type in baseBakeInfo):
                nodeListExclude.append(i[0].outputs[baseBakeInfo[i[0].type]["Output"]].links[0].to_node)
            else:
                nodeListExclude.append(i[0])
        if(bakeType not in bpy.context.scene.DontMax):
            MaxOutOut(unpackedMat,nodeListExclude)
        
        if (selected != None and imageObj.enabled and len(selected.data.materials)>matSlot):
            selectedMat=selected.data.materials[matSlot]
            ogMats[selectedMat]=[matSlot,selected]
            UnpackselectedMat = GetUnpackedMateria(selectedMat,matSlot,selected,False)
            TrashData.cleanedMat.add(UnpackselectedMat)
            DeleteUnusedNode(UnpackselectedMat)
            BakeSelectedInputNodesUnpacked=GetAllInputNode(
                UnpackselectedMat, inputNodeType[bakeType], bakeType)
            selectedMaterialOutPut = GetNodeMat(
                UnpackselectedMat, "OUTPUT_MATERIAL", "Material OutPut Surface")

            if (BakeSelectedInputNodesUnpacked == False):
                if(not selectedMaterialOutPut):
                    materialOutputExcludeSelected:Node=selectedMaterialOutPut[0]
                    materialOutputMatSelected:Material=selectedMaterialOutPut[1]
                    materialOutputMatSelected.node_tree.nodes.remove(materialOutputExcludeSelected)
                foundEmptyOneSelected=True
                continue  # here
            if (selectedMaterialOutPut == False):
                foundEmptyOneSelected=True
                continue   # here
            
            nodeListSelectedExclude=[]
            for i in BakeSelectedInputNodesUnpacked:
                if(i[0].type in baseBakeInfo):
                    nodeListSelectedExclude.append(i[0].outputs[baseBakeInfo[i[0].type]["Output"]].links[0].to_node)
            else:
                nodeListSelectedExclude.append(i[0])
            
            if(bakeType not in bpy.context.scene.DontMax):
                MaxOutOut(UnpackselectedMat,nodeListSelectedExclude)
        
        ImageBakeData[mat] = []
        furtherConnectionData[mat] = []
        defaultData[mat] = None
        
        if (firstBakedImage == None):
            if 0 in existingImages[bakeType]:
                firstBakedImage = existingImages[bakeType][0]
            else:
                firstBakedImage = ImageB(mat.name,udimCount,mesh.name,imageObj)
            firstBakedImage.AddImageNode(unpackedMat)
            
            imagesAddedSoFar.append(firstBakedImage.image)
            ImageBakeData[mat]=[firstBakedImage, mesh,unpackedMat,Channel.FULL]
        elif(bpy.context.scene.BakeMulitpleSlots):
            firstBakedImage.AddImageNode(unpackedMat)
            ImageBakeData[mat]=[firstBakedImage, mesh,unpackedMat,Channel.FULL]
        else:
            if matSlot in existingImages[bakeType]:
                newBakeImage = existingImages[bakeType][matSlot]
            else:
                newBakeImage = ImageB(mat.name,udimCount,mesh.name,imageObj)
            newBakeImage.AddImageNode(unpackedMat)
            imagesAddedSoFar.append(newBakeImage.image)
            ImageBakeData[mat]=[newBakeImage, mesh,unpackedMat,Channel.FULL]

        if (selected and bpy.context.scene.BakeMultiple and len(bpy.context.scene.my_items) > 1 and imageObj.enabled) :
            if(firstBakedImageSelected==None):
                firstBakedImageSelected = ImageB(unpackedMat.name,udimCount,mesh.name,imageObj)
                firstBakedImageSelected.AddImageNode(unpackedMat)
                TrashData.images.add(firstBakedImageSelected.image)
                furtherConnectionData[unpackedMat]=[firstBakedImageSelected, mesh,materialOutput[0]]
            elif(bpy.context.scene.BakeMulitpleSlots):
                newImageNodeSelected=firstBakedImageSelected.AddImageNode(unpackedMat)
                furtherConnectionData[unpackedMat]=[newImageNodeSelected, mesh,materialOutput[0]]
            else:
                newBakedImageSelected = ImageB(unpackedMat.name,udimCount,mesh.name,imageObj)
                newBakedImageSelected.AddImageNode(unpackedMat)
                TrashData.images.add(newBakedImageSelected.image)
                furtherConnectionData[unpackedMat]=[newBakedImageSelected, mesh,materialOutput[0]]


        for BakeInputNodeUnpacked in BakeInputNodesUnpacked:
            bakeNodeToAddUnpacked = BakeInputNodeUnpacked[0]
            if (shoulBake == False):
                currentState = PreBakeTypeCheck(
                    bakeNodeToAddUnpacked.inputs[inputNodeName[bakeType]])
                currentStatus=currentState[0]
                if (currentStatus == InputStatus.PROCEDUAL):
                    shoulBake = True
                    break
                currentValue=currentState[1]
                currentChannel=currentState[2]
                if (previouseState == None):
                    previouseState = currentState
                previouseStatus=previouseState[0]
                previouseValue=previouseState[1]
                previouseChannel=previouseState[2]
                if (shoulBake == False):
                    shoulBake = ValueCheck(currentStatus, currentValue ,previouseStatus, previouseValue,previouseChannel,currentChannel,bakeType,imageObj,udimCount)
                if (shoulBake == False):
                    if(type(previouseValue)==ShaderNodeTexImage):
                        valueToPut:ImageB=ImageB(mat.name,udimCount,mesh.name,imageObj,None,False,previouseValue.image)
                    else:
                        valueToPut=previouseValue
                    defaultData[mat]=[valueToPut,mesh,unpackedMat,currentChannel]
                else:
                    break
                if(not bpy.context.scene.BakeMulitpleSlots):
                    previouseState=None
                
                               
        if (selected != None and imageObj.enabled and BakeSelectedInputNodesUnpacked!= None):
            BakeInputNodesToUse = BakeSelectedInputNodesUnpacked
            materialOutputToUse=selectedMaterialOutPut
        else:
            materialOutputToUse=materialOutput
            BakeInputNodesToUse = BakeInputNodesUnpacked

        for BakeInputNode in BakeInputNodesToUse:
            currentValue = BakeInputNode[2]
            nodeTocheck = BakeInputNode[0]
            bakeMat: Material = BakeInputNode[1]
            ConnectionBake(bakeType, currentValue, nodeTocheck, bakeMat)
    
    UvManager.SetUv(uv,mesh)
    if (selected != None):
        selected.select_set(True)
    mesh.select_set(True)
    bpy.context.view_layer.objects.active = mesh
    
    if (bpy.context.scene.ShadeSmooth):
        bpy.ops.object.shade_smooth()
    if (shoulBake):
        return [True, ImageBakeData, furtherConnectionData,ogMats]
    if(not imageObj.enabled):
        defaultData={}
    TrashData.images.update(set(imagesAddedSoFar))
    return [False, defaultData, furtherConnectionData,ogMats]

    

def ValueCheck(currentStatus, currentValue ,previouseStatus, previouseValue,previouseChannel,currentChannel,bakeType,imageObj,udimCount):
    if (((previouseStatus == InputStatus.DEFAULT) and (currentStatus == InputStatus.DEFAULT)) and (previouseValue == currentValue) and (previouseChannel==currentChannel)):
        if((bakeType in PackedTexture.texture and imageObj.enabled)):
            shoulBake=True
        else:
            shoulBake = False
    elif (((previouseStatus == InputStatus.TEXTURE) and (currentStatus == InputStatus.TEXTURE)) and (previouseValue.image == currentValue.image)and (previouseChannel==currentChannel)):
        if((previouseValue.image.size[0]!=bpy.context.scene.width or previouseValue.image.size[0]!=bpy.context.scene.height) and (bakeType in PackedTexture.texture and imageObj.enabled)):
            shoulBake=True
        if(previouseValue.image.source!="TILED" and udimCount!=None):
            shoulBake=True
        else:
            if(previouseValue.image.source=="TILED" and udimCount!=None):
                allTiles=[tile.number for tile in previouseValue.image.tiles]
                for tile in udimCount:
                    if(tile not in allTiles):
                        shoulBake=True
            else:
                shoulBake = False
    else:
        shoulBake = True
    return shoulBake

def ConnectionBake(bakeType, value, nodeTocheck:Node, bakeMat):
    if((bakeType in bpy.context.scene.multipleShader) or (bakeType in bpy.context.scene.alwaysRequireMultires)):
        return
    baseBakeInfoConnection = bpy.context.scene.baseNode
    nodeTouse=nodeTocheck
    if((nodeTocheck.type in baseBakeInfoConnection)):
        nodeTouse= nodeTocheck.outputs[baseBakeInfoConnection[nodeTocheck.type]["Output"]].links[0].to_node
    principleBsdf: Node = bakeMat.node_tree.nodes.new(
                    type="ShaderNodeBsdfPrincipled")
    defaultValue = None
    connection = None
    if(nodeTocheck.type=='BSDF_PRINCIPLED'):
        connection=bpy.context.scene.inputNodeNames[bakeType]
        if(bakeType in bpy.context.scene.propertyDependentInput):
            setattr(principleBsdf, bpy.context.scene.propertyDependentInput[bakeType]["Property"],bpy.context.scene.propertyDependentInput[bakeType]["PropertyAccept"][0])
    if (bakeType in bpy.context.scene.requiresConnection ):
        connection = bpy.context.scene.requiresConnection[bakeType]
        if(connection=="Emission Color"):
            principleBsdf.inputs["Emission Strength"].default_value = 1.0
    if (bakeType in bpy.context.scene.requiresDefaultValue):
        defaultValue = bpy.context.scene.requiresDefaultValue[bakeType]
    if(bakeType in bpy.context.scene.requiredChannels):
        baketype=GetInputValueRaw(bpy.context.scene.requiredChannels[bakeType],nodeTocheck)
        Connection.CreateLink(bakeMat, principleBsdf, baketype, "Emission Strength")
    linked=nodeTouse.outputs[0].is_linked
    inputSocket: NodeSocket = nodeTouse.outputs[0].links[0].to_socket
    connectedNode: Node = nodeTouse.outputs[0].links[0].to_node
    if (bakeType in bpy.context.scene.ConvertInput):
        inputToConvert=bpy.context.scene.ConvertInput[bakeType]
        if (bakeType in bpy.context.scene.VolumeInputs):
            if(inputToConvert in connectedNode.inputs):
                inputSocket=connectedNode.inputs[inputToConvert]
        else:
            inputSocket=connectedNode.inputs[inputToConvert]
    if (defaultValue):
        Connection.CreateLink(bakeMat, principleBsdf, defaultValue, "Emission Strength")
    if (connection):
        Connection.CreateLink(bakeMat, principleBsdf, value, connection)
    Connection.CreateLink(bakeMat, inputSocket.node, principleBsdf.outputs[0], inputSocket)
    if(connectedNode.type=="MIX_SHADER"):
        if(connectedNode.inputs[1]==inputSocket):
            if(not connectedNode.inputs[2].is_linked):
                Connection.CreateLink(bakeMat,connectedNode,0,0)
        elif (not connectedNode.inputs[1].is_linked):
            Connection.CreateLink(bakeMat,connectedNode,1,0)


def MaxOutOut(unpackedMat,exclusionList):
    toDisconnectShaders=GetAllNode(unpackedMat,bpy.context.scene.shaderNodes,exclusionList)
    combinationShaders=GetAllNode(unpackedMat,bpy.context.scene.CombinationShader,[])
    if(toDisconnectShaders):
        tempDictionary={}
        while len(toDisconnectShaders)>=1:
            for shaderNodes in toDisconnectShaders:
                if(not shaderNodes.outputs[0].is_linked):
                    continue
                connection:NodeSocket=shaderNodes.outputs[0].links[0].to_socket
                fromNode:Node=connection.node
                if(fromNode.type=="MIX_SHADER"):
                    socketInt=2
                    otherSocket=1
                else:
                    socketInt=0
                    otherSocket=1
                if(fromNode.inputs[1]==connection):
                    temp=socketInt
                    socketInt=otherSocket
                    otherSocket=temp
                value=Connection.BreakLink(fromNode,unpackedMat,socketInt)
                if((not fromNode.inputs[otherSocket].is_linked) and (fromNode not in toDisconnectShaders) and (fromNode.type!="OUTPUT_MATERIAL") and (fromNode.outputs[0].is_linked)):
                    tempDictionary[fromNode]=unpackedMat
            toDisconnectShaders=tempDictionary.copy()
            tempDictionary.clear()
    if(combinationShaders):
        for combinationShader in combinationShaders:
            if(combinationShader.type=="MIX_SHADER"):
                combinationShader:Node=combinationShader
                if(combinationShader.inputs[1].is_linked):
                    if(not combinationShader.inputs[2].is_linked):
                        Connection.CreateLink(combinationShaders[combinationShader],combinationShader,0,0)
                elif(combinationShader.inputs[2].is_linked):
                    if(not combinationShader.inputs[1].is_linked):
                       Connection.CreateLink(combinationShaders[combinationShader],combinationShader,1,0)

def GetInputValueRaw(BakeType: str, BakeInputNode: Node):
    NodeSocketValue: NodeSocket = BakeInputNode.inputs[bpy.context.scene.inputNodeNames[
        BakeType]]
    
    if (NodeSocketValue.is_linked):
        Value = NodeSocketValue.links[0].from_socket
        return Value
    if(bpy.context.scene.inputNodeNames[BakeType]=="Surface"):
        return False
    valueToCheck = NodeSocketValue.default_value
    if ((type(valueToCheck) == float) or (type(valueToCheck) == int)):
        Value = valueToCheck
    else:
        Value = valueToCheck[:]
    return Value

def RestoreData(ogMats):
    for mat in ogMats:
        ogMats[mat][1].material_slots[ogMats[mat][0]].material=mat
    TrashData.DeletePartial()
    
    
def copyNodeGroup(Mats: Material):
    nodeGroup = []
    nodeTree=[]
    for node in Mats.node_tree.nodes:
        if (type(node) == bpy.types.ShaderNodeGroup):
            group = node.node_tree
            if(group):
                copied = group.copy()
                node.node_tree = copied
                nodeGroup.append(node)
                nodeTree.append(node.node_tree)
    for groups in nodeGroup:
        deepCopy=copyNodeGroup(groups)
        nodeTree=list(set(nodeTree+deepCopy))
    return nodeTree
def GetNodeGroup(Mats:Material):
    nodeGroup = []
    nodeTree=[]
    for node in Mats.node_tree.nodes:
        if (type(node) == bpy.types.ShaderNodeGroup):
            if(node.node_tree):
                nodeTree.append(node.node_tree)
                nodeGroup.append(node)
    for groups in nodeGroup:
        deepCopy=GetNodeGroup(groups)
        nodeTree=list(set(nodeTree+deepCopy))
    return nodeTree



def BakeNow():
    createdMaterial = {}
    existingImages:dict[str,dict[int,ImageB]] = {}
    maxMultipleBakeImageSlot = 0
    bakeObjectList = {}
    uvFullCheck = CombineUvUdimCheck(4)
    useUv = uvFullCheck[1]
    udimTiles = uvFullCheck[0]
    CreateUv(useUv)
    for obj in bpy.context.scene.my_items:
        for bakeObj in bpy.context.scene.bakingList:
            shouldBakeCheck = (bakeObj.enabled) or (bpy.context.scene.BakeMulitpleSlots and ((bakeObj.name not in bpy.context.scene.allwaysRequireBaking)) and (bpy.context.scene.ApplyMaterial) and (bpy.context.scene.CollapseSlot))
            if (shouldBakeCheck):
                if (bakeObj not in bakeObjectList):
                    bakeObjectList[bakeObj] = []
                bakeObjectList[bakeObj].append(obj)
    if (bpy.context.scene.BakeMultiple or bpy.context.scene.BakeMulitpleSlots):
        if (bpy.context.scene.BakeMulitpleSlots):
            maxMultipleBakeImageSlot = 1
        else:
            for obj in bpy.context.scene.my_items:
                if ((len(obj.mesh.data.materials) > maxMultipleBakeImageSlot)):
                    maxMultipleBakeImageSlot = len(obj.mesh.data.materials)

    for bakeObj in bakeObjectList:
        bakeType = bakeObj.name
        existingImages[bakeType] = {}
        matToRestore = []
        multiResModifiers:dict[Object,Modifier] = {}
        multiplebake:dict[Material,ImageB]={}
        tempData=[]
        for MeshObj in bakeObjectList[bakeObj]:
            mesh:Object = MeshObj.mesh
            selectCageInfo = [MeshObj.selected, MeshObj.cage]
            selectCageLocation = {}
            selectCageRotation = {}
            selectedObject = MeshObj.selected
            cageObject = MeshObj.cage
            for objectsSelectCage in selectCageInfo:
                if (objectsSelectCage):
                    selectCageLocation[objectsSelectCage] = objectsSelectCage.location[:]
                    selectCageRotation[objectsSelectCage] = objectsSelectCage.rotation_euler[:]
            needMultiRes = bpy.context.scene.alwaysRequireMultires
            
            if (bakeType in needMultiRes):
                foundOne=False
                for modifiers in mesh.modifiers:
                    if (modifiers.type == "MULTIRES"):
                        multiResModifiers[mesh] =modifiers
                        foundOne=True
                if (len(mesh.modifiers) == 0 and not foundOne):
                    continue
            bpy.ops.object.select_all(action="DESELECT")
            if (bpy.context.scene.BakeMultiple and bpy.context.scene.UseUdims):
                tilesToUse:set[int]=set()
                wasNone=True
                for mesh in udimTiles:
                    if(udimTiles[mesh]!=None):
                        tilesToUse.update(udimTiles[mesh])
                        wasNone=False
                if(wasNone):
                    tilesToUse=None
            else:
                tilesToUse = udimTiles[mesh]
            
            if(len(existingImages[bakeType])<=0):
                for i in range(maxMultipleBakeImageSlot):
                    if(len(mesh.data.materials)>i):
                        matNameToUse=mesh.data.materials[i].name
                    else:
                        matNameToUse=mesh.data.materials[len(mesh.data.materials)-1].name
                    matNameToUse=Name.GetMatNameToUse(matNameToUse,bakeObj.enabled)
                    meshNameToUse=Name.GetMeshNameToUse(mesh,bakeObj.enabled)
                    existingImages[bakeType][i] = ImageB(matNameToUse,tilesToUse,meshNameToUse,bakeObj)
            
            BakedMap = BakeMap(MeshObj.uv, mesh, bakeType, tilesToUse, bakeObj, selectedObject, existingImages)
            tempData.append(BakedMap[2])
            matToRestore.append(BakedMap[3])
            for mat in BakedMap[1]:
                items=BakedMap[1][mat]
                if(items==None):
                    continue
                if (mat not in createdMaterial):
                    createdMaterial[mat] = {}
                if (bakeType not in createdMaterial[mat]):
                    createdMaterial[mat][bakeType] = None
                createdMaterial[mat][bakeType]=[
                    items[0], items[1],bakeObj,items[3],BakedMap[0]]
                if(type(items[0])==ImageB):
                    multiplebake[items[2]]=items[0]
            if (BakedMap[0]):
                if(bakeObj.enabled):
                    for objectsSelectCage in selectCageInfo:
                        if (objectsSelectCage):
                            objectsSelectCage.location = mesh.location
                            objectsSelectCage.rotation_euler = mesh.rotation_euler
                    bpy.context.scene.render.bake.use_selected_to_active = selectedObject != None
                    bpy.context.scene.render.bake.use_cage = cageObject != None
                    if (bpy.context.scene.render.bake.use_cage):
                        bpy.context.scene.render.bake.cage_object = cageObject
                if (bpy.context.scene.BakeMultiple == False or selectedObject != None or not bakeObj.enabled):
                    BakeFinal(bakeType,
                              multiResModifiers, needMultiRes,False)
                for objectsSelectCage in selectCageInfo:
                    if (objectsSelectCage):
                        objectsSelectCage.location = selectCageLocation[objectsSelectCage]
                        objectsSelectCage.rotation_euler = selectCageRotation[objectsSelectCage]
            
            if(not BakedMap[0]):
                for i in existingImages[bakeType]:
                    TrashData.images.add(existingImages[bakeType][i].image)
            if(bpy.context.scene.BakeMulitpleSlots and (not bpy.context.scene.BakeMultiple or not bakeObj.enabled)):
                existingImages[bakeType]={}
            

        if (bpy.context.scene.BakeMultiple and bakeObj.enabled and len(bpy.context.scene.my_items) > 1):
            for matData in tempData:
                for mat in matData:
                    TempConnection(bakeType, mat, matData)
            bpy.ops.object.select_all(action="DESELECT")
            bpy.context.scene.render.bake.use_selected_to_active = False
            for obj in bpy.context.scene.my_items:
                meshSecond = obj.mesh
                meshSecond.select_set(True)
                bpy.context.view_layer.objects.active = mesh
            for mat in multiplebake:
                multiplebake[mat].SelectNode(mat)
            BakeFinal(bakeType,multiResModifiers, needMultiRes,True)
        if (bakeType in needMultiRes):
            for obj in multiResModifiers:
                obj.modifiers.remove(multiResModifiers[obj])
        for matData in matToRestore:
            RestoreData(matData)

    
    return createdMaterial

def TempConnection(bakeType, mat:Material, connectionData):
    if(len(connectionData[mat])>0):
        defaultValue = None
        connecton = None
        materialOutput=connectionData[mat][2]
        value:ShaderNodeTexImage=connectionData[mat][0].AddImageNode(mat)
        outPutSocket:NodeSocket=value.outputs[0]
        principleBsdf: Node = mat.node_tree.nodes.new(
                    type="ShaderNodeBsdfPrincipled")
        shaderNode=bpy.context.scene.inputNode[bakeType]
        if(shaderNode=='BSDF_PRINCIPLED'):
            connecton=bpy.context.scene.inputNodeNames[bakeType]
            if(bakeType in bpy.context.scene.propertyDependentInput):
                setattr(principleBsdf, bpy.context.scene.propertyDependentInput[bakeType]["Property"],bpy.context.scene.propertyDependentInput[bakeType]["PropertyAccept"][0])
        if (bakeType in bpy.context.scene.requiresConnection ):
            connecton = bpy.context.scene.requiresConnection[bakeType]
            if(connecton=="Emission Color"):
                principleBsdf.inputs["Emission Strength"].default_value = 1.0
        if (bakeType in bpy.context.scene.requiresDefaultValue):
            defaultValue = bpy.context.scene.requiresDefaultValue[bakeType]
        if(bakeType in bpy.context.scene.multipleShader):
            connecton="Strength"
        if(connecton=="Normal" or bakeType in bpy.context.scene.normalsBake):
            normalNode:Node=mat.node_tree.nodes.new(type="ShaderNodeNormalMap")
            Connection.CreateLink(mat,normalNode,outPutSocket,"Color")
            outPutSocket=normalNode.outputs[0]
            connecton="Normal"

        if (defaultValue):
            Connection.CreateLink(mat, principleBsdf, defaultValue, "Strength")
        if (connecton):
            Connection.CreateLink(mat, principleBsdf, outPutSocket, connecton)

        Connection.CreateLink(mat,materialOutput,principleBsdf.outputs[0],"Surface")


def BakeFinal(bakeType, multiResModifiers, needMultiRes,furthurBake):
    bakingSelection = bpy.context.scene.BakingSelection
    if(furthurBake):
        if(bakeType in bpy.context.scene.normalsBake):
            bpy.ops.object.bake(type="NORMAL")
        elif(bakeType in bpy.context.scene.multipleShader):
            bpy.ops.object.bake(type="EMIT")
        else:
            if (bakingSelection[bakeType] == "DIFFUSE"):
                bpy.ops.object.bake(type="DIFFUSE", pass_filter={"COLOR"})
            else:
                bpy.ops.object.bake(type=bakingSelection[bakeType])
    elif (bakeType in needMultiRes):
        for obj in multiResModifiers:
            multiResModifiers[obj].levels = 0
        bpy.context.scene.render.use_bake_multires = True
        bpy.context.scene.render.bake_type = bakingSelection[bakeType]
        bpy.ops.object.bake_image()
    elif (bakingSelection[bakeType] == "DIFFUSE"):
        bpy.ops.object.bake(type="DIFFUSE", pass_filter={"COLOR"})
    else:
        bpy.ops.object.bake(type=bakingSelection[bakeType])


def AntiAlias(createdMaterial,mat:Material):
    if (bpy.context.scene.AntialiasingScale != 1):
        for bakeType in createdMaterial[mat]:
            value = createdMaterial[mat][bakeType][0]
            if(type(value)==ImageB and (not value.scaled) and (createdMaterial[mat][bakeType][4] and createdMaterial[mat][bakeType][2].enabled)):
                with bpy.context.temp_override(**{'edit_image': value.image}):
                    bpy.ops.image.resize(size=(bpy.context.scene.width, bpy.context.scene.height),all_udims=value.tiles!=None)
                value.scaled=False


def Restore(currentEngine, currentDevice, previousState, modePrev, extrusion, rayDistance, margin,currentMinSample,currentMaxSample):
    TrashData.Delete()
    bpy.context.scene.cycles.preview_samples=currentMinSample
    bpy.context.scene.cycles.preview_adaptive_min_samples=currentMaxSample
    bpy.context.scene.render.bake.cage_extrusion = extrusion
    bpy.context.scene.render.bake.margin = margin
    bpy.context.scene.render.bake.max_ray_distance = rayDistance
    bpy.context.scene.render.engine = currentEngine
    bpy.context.scene.cycles.device = currentDevice
    bpy.context.area.ui_type = previousState
    try:
        bpy.ops.object.mode_set(mode=modePrev)
    except:
        print("Issue in restoring setting")


def BakingSetUp():
    for obj in bpy.context.scene.my_items:
        mesh = obj.mesh
        mesh.select_set(True)
        bpy.context.view_layer.objects.active = mesh
        for i in range(len(mesh.data.materials)-1,-1,-1):
            mat= mesh.data.materials[i]
            if(mat== None):
                mesh.data.materials.pop(index=i)
        bpy.ops.object.select_all(action="DESELECT")
    mode = bpy.context.mode
    areaTypeOld = bpy.context.area.ui_type
    bpy.context.area.ui_type = "VIEW_3D"
    currentEngine = bpy.context.scene.render.engine
    currentDevice = bpy.context.scene.cycles.device
    extrusion = bpy.context.scene.render.bake.cage_extrusion
    currentRaydistance = bpy.context.scene.render.bake.max_ray_distance
    currentMargin = bpy.context.scene.render.bake.margin
    currentMinSample=bpy.context.scene.cycles.preview_adaptive_min_samples
    currentMaxSample=bpy.context.scene.cycles.preview_samples
    bpy.context.scene.render.bake.max_ray_distance = bpy.context.scene.rayDistance
    bpy.context.scene.cycles.device = bpy.context.scene.Device
    bpy.context.scene.render.engine = "CYCLES"
    bpy.context.scene.render.bake.cage_extrusion = bpy.context.scene.extrusion
    bpy.context.scene.render.bake.margin = bpy.context.scene.margin
    bpy.context.scene.cycles.preview_samples=bpy.context.scene.sampling
    bpy.context.scene.cycles.preview_adaptive_min_samples=0
    
    try:
        bpy.ops.object.mode_set(mode="OBJECT")
    except:
        print("issue in setting pre bake")
    return currentEngine, currentDevice, areaTypeOld, mode, extrusion, currentRaydistance, currentMargin,currentMinSample,currentMaxSample



def GetColor(udimCount: int, channel,channelToTake:Channel,isAlpha):
    if(channelToTake==Channel.RED):
        takeChannel=0
    elif(channelToTake==Channel.GREEN):
        takeChannel=1
    elif(channelToTake==Channel.BLUE):
        takeChannel=2
    elif(channelToTake==Channel.ALPHA):
        takeChannel=3
    else:
        takeChannel=0
    if(isinstance(channel, ImageB)):
        if(isinstance(udimCount, int)):
            if(channel.tiles!=None and udimCount in channel.tiles):
                loadedImage:Image=bpy.data.images.load(filepath=channel.GetFilePath(True,udimCount),check_existing=True)
                numpyChannel = numpy.array(loadedImage.pixels[:], dtype=numpy.float32).reshape((bpy.context.scene.width * bpy.context.scene.height, 4))
                returnChannel = numpyChannel[:, takeChannel]
                TrashData.images.add(loadedImage)
                return returnChannel
            else:
                if(udimCount==1001):
                    loadedImage:Image=bpy.data.images.load(filepath=channel.GetFilePath(True,None),check_existing=True)
                    numpyChannel = numpy.array(loadedImage.pixels[:], dtype=numpy.float32).reshape((loadedImage.size[0] * loadedImage.size[1], 4))
                    returnChannel = numpyChannel[:, takeChannel]
                    TrashData.images.add(loadedImage)
                    return returnChannel
                else:
                    zeros=numpy.zeros((bpy.context.scene.width * bpy.context.scene.height, 4), dtype=numpy.float32)
                    returnChannel = zeros[:, 0]
                    return returnChannel
        else:
            loadedImage:Image=bpy.data.images.load(filepath=channel.GetFilePath(True,None),check_existing=True)
            numpyChannel = numpy.array(loadedImage.pixels[:], dtype=numpy.float32).reshape((loadedImage.size[0] * loadedImage.size[1], 4))
            returnChannel = numpyChannel[:, takeChannel]
            TrashData.images.add(loadedImage)
            return returnChannel
    else:
        zeros=numpy.zeros((bpy.context.scene.width * bpy.context.scene.height, 4), dtype=numpy.float32)
        returnChannel = zeros[:, 0]
        return returnChannel
        

def createMat(bakeDate,mat,newCreatedMats,matToDelete):
    newCreatedMats[mat]={}
    if((mat in matToDelete) or (not bpy.context.scene.ApplyMaterial) or CanApplyMaterial(mat)==False):
        return
    for bakeType in bakeDate[mat]:
        if (bakeDate[mat][bakeType][4]==False ):
            continue
        if(bakeType not in newCreatedMats[mat]):
            newCreatedMats[mat][bakeType]=[]
        inputs=GetAllNodeMat(mat,bpy.context.scene.inputNode[bakeType],bakeType)
        for input in inputs:
            bakeMat:Material=input[1]
            bakeNode:Node=input[0]
            texture:ImageB=bakeDate[mat][bakeType][0]
            ImageNode:ShaderNodeTexImage=texture.AddImageNode(bakeMat)
            channel:Channel=bakeDate[mat][bakeType][3]
            if(channel==Channel.FULL):
                newCreatedMats[mat][bakeType].append([ImageNode.outputs["Color"],bakeMat,bakeNode,bakeDate[mat][bakeType][1],bakeDate[mat][bakeType][2]])
            elif(channel==Channel.ALPHA):
                newCreatedMats[mat][bakeType].append([ImageNode.outputs["Alpha"],bakeMat,bakeNode,bakeDate[mat][bakeType][1],bakeDate[mat][bakeType][2]])
            else:
                seperateNode:ShaderNodeSeparateColor=texture.AddSeperateNode(ImageNode,bakeMat)
                newCreatedMats[mat][bakeType].append([seperateNode.outputs[channel.value],bakeMat,bakeNode,bakeDate[mat][bakeType][1],bakeDate[mat][bakeType][2]])


def CanApplyMaterial(mat:Material):
    allShaderNode=GetAllNode(mat,bpy.context.scene.shaderNodes,[])
    allCombinationNode=GetAllNode(mat,bpy.context.scene.CombinationShader,[])
    shaderNodeTypes=[]
    CombinationTypes=[]
    if(allShaderNode):
        shaderNodeTypes=list(set([i.type for i in allShaderNode]))
    if(allCombinationNode):
        CombinationTypes=list(set([i.type for i in allCombinationNode]))
    if(("ADD_SHADER" in CombinationTypes) or (len(shaderNodeTypes)>1)):
        return False
    else:
        return True
    

def Start():
    matToDelete=[]
    newCreatedMats = {}
    createdJson = {}

    objectData:List[ObjectData]=[]
    for packedObj in bpy.context.scene.my_Packed_Object:
        if(packedObj.enabled):
            if(packedObj.Red!=None):
                PackedTexture.texture.add(packedObj.Red)
            if(packedObj.Green!=None):
                PackedTexture.texture.add(packedObj.Green)
            if(packedObj.Blue!=None):
                PackedTexture.texture.add(packedObj.Blue)
            if(packedObj.Alpha!=None):
                PackedTexture.texture.add(packedObj.Alpha)

    currentEngine, currentDevice, previousState, mode, extrusion, rayDistance, margin,currentMinSample,currentMaxSample = BakingSetUp(
    )
    if (len(bpy.context.scene.my_items) == 0):
        return   # here
    else:
        for obj in bpy.context.scene.my_items:
            ObjData = ObjectData(obj.mesh)

            objectData.append( ObjData)
    bakeData = BakeNow()
    
    packedImages:dict[ImageB,list[ImageB,Channel]]={}

    for data in objectData:
        data.SetMat()
        data.RemoveFromData(bakeData)
    for mat in bakeData:
        newCreatedMats[mat] = {}
        Fliping(bakeData, mat)
        PackTexture(bakeData, mat,packedImages)
        AntiAlias(bakeData,mat)
        createMat(bakeData,mat,newCreatedMats,matToDelete)
        SaveAllImages(bakeData,mat)
        createJson(bakeData, mat, createdJson)
        

    ApplyMaterial(newCreatedMats)
    ExportUpdateJson(createdJson)
    Restore(currentEngine, currentDevice,
                   previousState, mode, extrusion, rayDistance, margin,currentMinSample,currentMaxSample)


def SaveAllImages(bakeDate,mat):
    for finalBakeType in bakeDate[mat]:
        try:
            image= bakeDate[mat][finalBakeType][0]
            if (type(image)==ImageB):
                image.SaveImage(False)
        except Exception as e:
            print(f"print issue saving image {e}")


def ExportUpdateJson(createdJson):
    jsonExportPath=f"{bpy.context.scene.basePath}MappingFile\\"
    jsonPath=f"{jsonExportPath}mapping.json"
    dataPrevious={}
    os.makedirs(jsonExportPath, exist_ok=True)
    if(os.path.isfile(jsonPath)):
        with open(jsonPath, "r") as jsonFile:
            dataPrevious = json.load(jsonFile)
    with open(jsonPath, "w") as jsonFile:
        for mat in dataPrevious:
            for bakeType in dataPrevious[mat]:
                if(mat in createdJson):
                    if(bakeType not in createdJson[mat]):
                        createdJson[mat][bakeType]=dataPrevious[mat][bakeType]
                else:
                    createdJson[mat]=dataPrevious[mat]
        json.dump(createdJson, jsonFile)


def ApplyMaterial(newCreatedMats):
    
    for mats in newCreatedMats:
        GetBlendings(newCreatedMats, mats)
        for finalBakeType in newCreatedMats[mats]:
            for items in newCreatedMats[mats][finalBakeType]:
                matsTree: Material = items[1]
                FlipSocket(items, matsTree)
                CheckAddionStep(items, finalBakeType, matsTree)
                outputNode: Node = items[0]
                socketName = bpy.context.scene.inputNodeNames[finalBakeType]
                inputNode: Node = items[2]
                Connection.CreateLink(matsTree, inputNode,
                          outputNode, socketName)

                afterBake = bpy.context.scene.RequireAfterProcess
                if (finalBakeType in afterBake):
                    for afterInputs in afterBake[finalBakeType]:
                        Connection.CreateLink(mats, inputNode,
                                  afterBake[finalBakeType][afterInputs], afterInputs)
        DeleteUnusedNode(mats)
    for obj in bpy.context.scene.my_items:
        mesh: Object = obj.mesh
        uvName:str=obj.uv
        mesh.data.uv_layers[uvName].active_render = True

def CheckAddionStep(items, finalBakeType, matsTree):
    requireAdditonSteps = bpy.context.scene.multiResSetup
    oldValue: NodeSocket = items[0]
    if (finalBakeType in requireAdditonSteps):
        tempNode = oldValue.node
        if (tempNode.bl_idname != requireAdditonSteps[finalBakeType]["Node"]):
            value = None
            if (((type(oldValue) == float) or (type(oldValue) == int))):
                value = oldValue
            else:
                value = requireAdditonSteps[finalBakeType]["InputOutputName"]

            try:
                node = oldValue.node
                if (node.inputs[requireAdditonSteps[finalBakeType]["OriginInput"]].is_linked):
                    newNode = node.inputs[requireAdditonSteps[finalBakeType]
                                        ["OriginInput"]].links[0].from_node
            except:
                newNode = matsTree.node_tree.nodes.new(
                    type=requireAdditonSteps[finalBakeType]["Node"])
            Connection.CreateLink(matsTree, newNode,
                    oldValue, value)
            items[0] = newNode.outputs[requireAdditonSteps[finalBakeType]["Output"]]


def FlipSocket(items, matsTree):
    flippingInfo = {"Red":items[4].Red,"Green":items[4].Green,"Blue":items[4].Blue}
    if (items[4].Invert):
        invertNode = matsTree.node_tree.nodes.new(type="ShaderNodeInvert")
        Connection.CreateLink(matsTree, invertNode, items[0],
                    "Color")
        items[0] = invertNode.outputs["Color"]
    elif(items[4].Red or items[4].Green or items[4].Blue):
        seperateColorNode = matsTree.node_tree.nodes.new(
            type="ShaderNodeSeparateColor")
        combineColorNode = matsTree.node_tree.nodes.new(
            type="ShaderNodeCombineColor")

        Connection.CreateLink(matsTree, seperateColorNode, items[0],
                    "Color")
        for channel in flippingInfo:
            if (channel != "Alpha"):
                if (flippingInfo[channel]):
                    invertNode = matsTree.node_tree.nodes.new(
                        type="ShaderNodeInvert")
                    Connection.CreateLink(matsTree,
                                invertNode, seperateColorNode.outputs[channel], "Color")
                    Connection.CreateLink(matsTree, combineColorNode,
                                invertNode.outputs["Color"], channel)
                else:
                    Connection.CreateLink(matsTree, combineColorNode,
                                seperateColorNode.outputs[channel], channel)
        items[0] = combineColorNode.outputs["Color"]


def Fliping(bakeDate, mat):
    for bakeType in bakeDate[mat]:
        obj=bakeDate[mat][bakeType][2]
        if((obj.Red or obj.Green or obj.Blue  or obj.Invert) and (obj.enabled)):
            Invert(bakeDate, mat, bakeType)


def Invert(bakeDate, mat, bakeType):
    value = bakeDate[mat][bakeType][0]
    imageObj=bakeDate[mat][bakeType][2]
    if(type(value)==tuple):
        value=bakeDate[mat][bakeType][0][:]
        bakeDate[mat][bakeType][0]=tuple(1-x for x in value) 
    elif(type(value)==ImageB and not value.inverted):
        with bpy.context.temp_override(**{'edit_image': value.image}):
            bpy.ops.image.invert(invert_r=(imageObj.Red or imageObj.Invert),invert_g=(imageObj.Green or imageObj.Invert),invert_b=(imageObj.Blue or imageObj.Invert))
        value.image.update()
        value.inverted=True
    elif(type(value)==int or type(value)==float):
        bakeDate[mat][bakeType][0]=1-bakeDate[mat][bakeType][0]


def GetBlendings(newCreatedMats, mats):
    blendingsDate = bpy.context.scene.Blending

    for blendingBakesList in blendingsDate:
        if (blendingBakesList in newCreatedMats[mats]):
            connectionObj = blendingsDate[blendingBakesList]
            properties = connectionObj["Properties"]
            inputs = connectionObj["Inputs"]
            alreadyAdded={}
            for checkingBake in newCreatedMats[mats][blendingBakesList]:
                ColorBake=bpy.context.scene.ColorMapNodeInverse[checkingBake[2].type]
                if(ColorBake not in newCreatedMats[mats]):
                    nodes=GetAllInputNode(mats,checkingBake[2].type,ColorBake)
                    for node in nodes:
                        if(ColorBake not in newCreatedMats[mats]):
                            newCreatedMats[mats][ColorBake]=[]
                        dataToAppend=[node[2],node[1],node[0],checkingBake[3],checkingBake[4]]
                        newCreatedMats[mats][ColorBake].append(dataToAppend)
                    continue
                else:
                    continue
            
            for blendingBake in newCreatedMats[mats][blendingBakesList]:
                for blendTexture in newCreatedMats[mats][bpy.context.scene.ColorMapNodeInverse[blendingBake[2].type]]:
                    if ((blendTexture[1] == blendingBake[1]) and (blendTexture[2] == blendingBake[2])):
                        if((blendTexture[1] in alreadyAdded) and (blendTexture[2] == alreadyAdded[blendTexture[1]][2])):
                            blendTexture[0]=alreadyAdded[blendTexture[1]][0]
                        else:
                            createdNode = GetMixShader(connectionObj, properties, inputs, blendingBake)
                            Connection.CreateLink(blendingBake[1],createdNode,blendTexture[0],"A")
                            Connection.CreateLink(blendingBake[1],createdNode,blendingBake[0],"B")
                            mats:Material= blendingBake[1]
                            blendTexture[0]=createdNode.outputs[2]
                            alreadyAdded[blendTexture[1]]=blendTexture

            del newCreatedMats[mats][blendingBakesList]

def GetMixShader(connectionObj, properties, inputs, primaryBake):
    createdNode: Node = primaryBake[1].node_tree.nodes.new(type=connectionObj["Node"])
    for property in properties:
        setattr(createdNode, property,
                            properties[property])
    for input in inputs:
        Connection.CreateLink(primaryBake[1], createdNode,
                                inputs[input], input)
                    
    return createdNode


def createJson(bakeDate, mat, createdJson):
    createdJson[mat.name]={}
    for bakedTextureType in bakeDate[mat]:
        valueData = bakeDate[mat][bakedTextureType][0]
        createdJson[mat.name][bakedTextureType] = {}
        textureValue=None
        floatValue=None
        xyz=None
        rgba=None
        isUdim=False
        tiles={}
        bakeObj=bakeDate[mat][bakedTextureType][2]
        createdJson[mat.name][bakedTextureType]["textureValue"] = {}
        mesh:Object=bakeDate[mat][bakedTextureType][1]
        if(type(valueData)==int or type(valueData)==float):
            floatValue=valueData
        elif (type(valueData) ==ImageB ):
            value = valueData.GetPaths(False)
            textureValue=value[1]
            isUdim=value[2]
            tiles=value[1]
        else:
            if(len(valueData)==3):
                xyz=list(valueData)
            else:
                rgba=list(valueData)
        createdJson[mat.name][bakedTextureType]["channel"] = bakeDate[mat][bakedTextureType][3].value
        createdJson[mat.name][bakedTextureType]["tiled"] = isUdim
        createdJson[mat.name][bakedTextureType]["mesh"] = mesh.name
        createdJson[mat.name][bakedTextureType]["shader"]=bakeObj.shaderNode
        createdJson[mat.name][bakedTextureType]["floatValue"] = floatValue
        createdJson[mat.name][bakedTextureType]["rgbaValue"] = rgba
        createdJson[mat.name][bakedTextureType]["xyzValue"] = xyz
        if(isUdim):
            for tile in tiles:
                tileTexture = tiles[tile]
                createdJson[mat.name][bakedTextureType]["textureValue"][tile] = tileTexture
        else:
            createdJson[mat.name][bakedTextureType]["textureValue"][0]=textureValue
def PackTexture(bakeDate, mat,packedImages:dict[ImageB,list[ImageB,Channel]]):

    for packedTexture in bpy.context.scene.my_Packed_Object:
        if(not packedTexture.enabled):
            continue
        tiles = []
        redBakeTexture = packedTexture.Red
        greenBakeTexture = packedTexture.Green
        blueBakeTexture = packedTexture.Blue
        alphaBakeTexture = packedTexture.Alpha
        if (redBakeTexture == "None"):
            redBakeTexture = None
        if (greenBakeTexture == "None"):
            greenBakeTexture = None
        if (blueBakeTexture == "None"):
            blueBakeTexture = None
        if (alphaBakeTexture == "None"):
            alphaBakeTexture = None
        
        redChannel = GetChannel(mat, redBakeTexture,
                                bakeDate)
        greenChannel = GetChannel(
            mat, greenBakeTexture, bakeDate)
        blueChannel = GetChannel(
            mat, blueBakeTexture, bakeDate)
        alphaChannel = GetChannel(
            mat, alphaBakeTexture, bakeDate)
        needPacking = redChannel[1] or greenChannel[1] or blueChannel[1] or alphaChannel[1]
        tiles:set[int]=set()
        
        if(redChannel[2]):
            tiles.update(redChannel[2])
        if(greenChannel[2]):
            tiles.update(greenChannel[2])
        if(blueChannel[2]):
            tiles.update(blueChannel[2])
        if(alphaChannel[2]):
            tiles.update(alphaChannel[2])
        if(len(tiles)<=0):
            tiles=None

        ChannelList = {redBakeTexture: [redChannel[1], Channel.RED], greenBakeTexture: [
            greenChannel[1], Channel.GREEN], blueBakeTexture: [blueChannel[1], Channel.BLUE], alphaBakeTexture: [alphaChannel[1], Channel.ALPHA]}
        
        mesh=None
        hasAll=True
        if (redChannel[1]):
            mesh = bakeDate[mat][redBakeTexture][1]
            currentImage:ImageB=redChannel[0]
            if(currentImage not in packedImages):
                hasAll=False
        if (greenChannel[1]):
            mesh = bakeDate[mat][greenBakeTexture][1]
            currentImage:ImageB=greenChannel[0]
            if(currentImage not in packedImages):
                hasAll=False
        if (blueChannel[1]):
            mesh = bakeDate[mat][blueBakeTexture][1]
            currentImage:ImageB=blueChannel[0]
            if(currentImage not in packedImages):
                hasAll=False
        if (alphaChannel[1]):
            mesh = bakeDate[mat][alphaBakeTexture][1]
            currentImage:ImageB=alphaChannel[0]
            if(currentImage not in packedImages):
                hasAll=False
        if(hasAll):
            for channel in ChannelList:
                if(channel!=None and ChannelList[channel][0]!=False):
                    currentImage:ImageB=bakeDate[mat][channel][0]
                    bakeDate[mat][channel][0]=packedImages[currentImage][0]
                    bakeDate[mat][channel][3]=packedImages[currentImage][1]
                    bakeDate[mat][channel][4]=True
            continue
        if(mesh==None):
            continue
        if (needPacking):
            meshNameToUse=Name.GetMeshNameToUse(mesh,hasAll)
            matNameToUse=Name.GetMatNameToUse(mat.name,hasAll)
            image = ImageB(matNameToUse,tiles,meshNameToUse,packedTexture,None,useAlpha=alphaChannel[1])
            image.SaveImage(True)
            bpy.data.images.remove(image=image.image)
            if (tiles!=None):
                for tile in tiles:
                    redCurrentColor = GetColor(
                        tile, redChannel[0], redChannel[3],False)
                    greenCurrentColor = GetColor(
                        tile, greenChannel[0], greenChannel[3],False)
                    blueCurrentColor = GetColor(
                        tile, blueChannel[0], blueChannel[3],False)
                    alphaCurrentColor = GetColor(
                        tile, alphaChannel[0], alphaChannel[3],True)
                    CreatePackedImage(packedTexture, image, tile, redCurrentColor, greenCurrentColor, blueCurrentColor, alphaCurrentColor)
                    
            else:
                redCurrentColor = GetColor(
                    None, redChannel[0], redChannel[3],False)
                greenCurrentColor = GetColor(
                    None, greenChannel[0], greenChannel[3],False)
                blueCurrentColor = GetColor(
                    None, blueChannel[0], blueChannel[3],False)
                alphaCurrentColor = GetColor(
                    None, alphaChannel[0], alphaChannel[3],True)
                CreatePackedImage(packedTexture, image, None, redCurrentColor, greenCurrentColor, blueCurrentColor, alphaCurrentColor)

            image.Reload(True)

            for channel in ChannelList:
                if(channel!=None and ChannelList[channel][0]!=False):
                    currentImage:ImageB=bakeDate[mat][channel][0]
                    bakeDate[mat][channel][0]=image
                    bakeDate[mat][channel][3]=ChannelList[channel][1]
                    bakeDate[mat][channel][4]=True
                    packedImages[currentImage]=[image,ChannelList[channel][1]]


def CreatePackedImage(packedTexture, image:ImageB, tile, redCurrentColor, greenCurrentColor, blueCurrentColor, alphaCurrentColor):
    path=image.GetFilePath(True,tile)
    
    tempImage=ImageB(image.matName,None,image.meshName,packedTexture,path,False)
    
    newPixels=numpy.stack([redCurrentColor, greenCurrentColor, blueCurrentColor,alphaCurrentColor], axis=1).flatten().tolist()
    TrashData.images.add(tempImage.image)
    tempImage.image.pixels=newPixels
    tempImage.SaveImage(True)
    TrashData.Delete()

def GetChannel(mat, bakeTexture, bakeDate):
    needPacking = False
    tiles = None
    takeChannels=Channel.FULL
    if (bakeTexture == None):
        channelData = 0
        needPacking = False
    else:
        if (bakeTexture in bakeDate[mat]):
            channelData = bakeDate[mat][bakeTexture][0]
            if (type(channelData) == ImageB):
                takeChannels=bakeDate[mat][bakeTexture][3]
                TrashData.images.add(channelData.image)
                channelData.SaveImage(True)
                needPacking = True
                if (channelData.tiles):
                    tiles = channelData.tiles
            else:
                channelData=0
                needPacking=False
        else:
            channelData = 0
            needPacking = False
    return [channelData,needPacking, tiles,takeChannels]




